(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[292],{9653:function(t,e,n){"use strict";n.d(e,{qY:function(){return c}});var r=n(7294),i=n(2446),o=(n(640),i.jU?r.useLayoutEffect:r.useEffect);function a(t,e=[]){const n=(0,r.useRef)(t);return o((()=>{n.current=t})),(0,r.useCallback)(((...t)=>{var e;return null==(e=n.current)?void 0:e.call(n,...t)}),e)}function s(t,e){const n=(0,r.useId)();return(0,r.useMemo)((()=>t||[e,n].filter(Boolean).join("-")),[t,e,n])}function c(t={}){const{onClose:e,onOpen:n,isOpen:o,id:c}=t,l=a(n),u=a(e),[f,d]=(0,r.useState)(t.defaultIsOpen||!1),[p,h]=function(t,e){const n=void 0!==t;return[n,n&&"undefined"!==typeof t?t:e]}(o,f),m=s(c,"disclosure"),y=(0,r.useCallback)((()=>{p||d(!1),null==u||u()}),[p,u]),g=(0,r.useCallback)((()=>{p||d(!0),null==l||l()}),[p,l]),b=(0,r.useCallback)((()=>{(h?y:g)()}),[h,g,y]);return{isOpen:!!h,onOpen:g,onClose:y,onToggle:b,isControlled:p,getButtonProps:(t={})=>({...t,"aria-expanded":h,"aria-controls":m,onClick:(0,i.v0)(t.onClick,b)}),getDisclosureProps:(t={})=>({...t,hidden:!h,id:m})}}},4902:function(t,e,n){"use strict";n.d(e,{xu:function(){return p},W2:function(){return y},rj:function(){return g},P4:function(){return x},MI:function(){return _},Kq:function(){return S},xv:function(){return C}});var r=n(7294),i=n(5818);function o(t){const e=typeof t;return null!=t&&("object"===e||"function"===e)&&!Array.isArray(t)}Object.freeze(["base","sm","md","lg","xl","2xl"]);function a(t,e){return Array.isArray(t)?t.map((t=>null===t?null:e(t))):o(t)?Object.keys(t).reduce(((n,r)=>(n[r]=e(t[r]),n)),{}):null!=t?e(t):null}var s=n(5336),c=n(4520);function l(t){const e=Object.assign({},t);for(let n in e)void 0===e[n]&&delete e[n];return e}var u=n(2494),f=n(8387);function d(t){return r.Children.toArray(t).filter((t=>(0,r.isValidElement)(t)))}(0,i.Gp)((function(t,e){const{ratio:n=4/3,children:o,className:c,...l}=t,u=r.Children.only(o),f=(0,s.cx)("chakra-aspect-ratio",c);return r.createElement(i.m$.div,{ref:e,position:"relative",className:f,_before:{height:0,content:'""',display:"block",paddingBottom:a(n,(t=>1/t*100+"%"))},__css:{"& > *:not(style)":{overflow:"hidden",position:"absolute",top:"0",right:"0",bottom:"0",left:"0",display:"flex",justifyContent:"center",alignItems:"center",width:"100%",height:"100%"},"& > img, & > video":{objectFit:"cover"}},...l},u)})).displayName="AspectRatio",(0,i.Gp)((function(t,e){const n=(0,i.mq)("Badge",t),{className:o,...a}=(0,c.Lr)(t);return r.createElement(i.m$.span,{ref:e,className:(0,s.cx)("chakra-badge",t.className),...a,__css:{display:"inline-block",whiteSpace:"nowrap",verticalAlign:"middle",...n}})})).displayName="Badge";var p=(0,i.m$)("div");p.displayName="Box";var h=(0,i.Gp)((function(t,e){const{size:n,centerContent:i=!0,...o}=t,a=i?{display:"flex",alignItems:"center",justifyContent:"center"}:{};return r.createElement(p,{ref:e,boxSize:n,__css:{...a,flexShrink:0,flexGrow:0},...o})}));h.displayName="Square",(0,i.Gp)((function(t,e){const{size:n,...i}=t;return r.createElement(h,{size:n,ref:e,borderRadius:"9999px",...i})})).displayName="Circle",(0,i.m$)("div",{baseStyle:{display:"flex",alignItems:"center",justifyContent:"center"}}).displayName="Center";var m={horizontal:{insetStart:"50%",transform:"translateX(-50%)"},vertical:{top:"50%",transform:"translateY(-50%)"},both:{insetStart:"50%",top:"50%",transform:"translate(-50%, -50%)"}};(0,i.Gp)((function(t,e){const{axis:n="both",...o}=t;return r.createElement(i.m$.div,{ref:e,__css:m[n],...o,position:"absolute"})}));(0,i.Gp)((function(t,e){const n=(0,i.mq)("Code",t),{className:o,...a}=(0,c.Lr)(t);return r.createElement(i.m$.code,{ref:e,className:(0,s.cx)("chakra-code",t.className),...a,__css:{display:"inline-block",...n}})})).displayName="Code";var y=(0,i.Gp)((function(t,e){const{className:n,centerContent:o,...a}=(0,c.Lr)(t),l=(0,i.mq)("Container",t);return r.createElement(i.m$.div,{ref:e,className:(0,s.cx)("chakra-container",n),...a,__css:{...l,...o&&{display:"flex",flexDirection:"column",alignItems:"center"}}})}));y.displayName="Container",(0,i.Gp)((function(t,e){const{borderLeftWidth:n,borderBottomWidth:o,borderTopWidth:a,borderRightWidth:l,borderWidth:u,borderStyle:f,borderColor:d,...p}=(0,i.mq)("Divider",t),{className:h,orientation:m="horizontal",__css:y,...g}=(0,c.Lr)(t),b={vertical:{borderLeftWidth:n||l||u||"1px",height:"100%"},horizontal:{borderBottomWidth:o||a||u||"1px",width:"100%"}};return r.createElement(i.m$.hr,{ref:e,"aria-orientation":m,...g,__css:{...p,border:"0",borderColor:d,borderStyle:f,...b[m],...y},className:(0,s.cx)("chakra-divider",h)})})).displayName="Divider",(0,i.Gp)((function(t,e){const{direction:n,align:o,justify:a,wrap:s,basis:c,grow:l,shrink:u,...f}=t,d={display:"flex",flexDirection:n,alignItems:o,justifyContent:a,flexWrap:s,flexBasis:c,flexGrow:l,flexShrink:u};return r.createElement(i.m$.div,{ref:e,__css:d,...f})})).displayName="Flex";var g=(0,i.Gp)((function(t,e){const{templateAreas:n,gap:o,rowGap:a,columnGap:s,column:c,row:l,autoFlow:u,autoRows:f,templateRows:d,autoColumns:p,templateColumns:h,...m}=t,y={display:"grid",gridTemplateAreas:n,gridGap:o,gridRowGap:a,gridColumnGap:s,gridAutoColumns:p,gridColumn:c,gridRow:l,gridAutoFlow:u,gridAutoRows:f,gridTemplateRows:d,gridTemplateColumns:h};return r.createElement(i.m$.div,{ref:e,__css:y,...m})}));function b(t){return a(t,(t=>"auto"===t?"auto":`span ${t}/span ${t}`))}g.displayName="Grid";var x=(0,i.Gp)((function(t,e){const{area:n,colSpan:o,colStart:a,colEnd:s,rowEnd:c,rowSpan:u,rowStart:f,...d}=t,p=l({gridArea:n,gridColumn:b(o),gridRow:b(u),gridColumnStart:a,gridColumnEnd:s,gridRowStart:f,gridRowEnd:c});return r.createElement(i.m$.div,{ref:e,__css:p,...d})}));x.displayName="GridItem",(0,i.Gp)((function(t,e){const n=(0,i.mq)("Heading",t),{className:o,...a}=(0,c.Lr)(t);return r.createElement(i.m$.h2,{ref:e,className:(0,s.cx)("chakra-heading",t.className),...a,__css:n})})).displayName="Heading";(0,i.Gp)((function(t,e){const n=(0,i.mq)("Mark",t),o=(0,c.Lr)(t);return r.createElement(p,{ref:e,...o,as:"mark",__css:{bg:"transparent",whiteSpace:"nowrap",...n}})}));(0,i.Gp)((function(t,e){const n=(0,i.mq)("Kbd",t),{className:o,...a}=(0,c.Lr)(t);return r.createElement(i.m$.kbd,{ref:e,className:(0,s.cx)("chakra-kbd",o),...a,__css:{fontFamily:"mono",...n}})})).displayName="Kbd",(0,i.Gp)((function(t,e){const n=(0,i.mq)("Link",t),{className:o,isExternal:a,...l}=(0,c.Lr)(t);return r.createElement(i.m$.a,{target:a?"_blank":void 0,rel:a?"noopener":void 0,ref:e,className:(0,s.cx)("chakra-link",o),...l,__css:n})})).displayName="Link";(0,i.Gp)((function(t,e){const{isExternal:n,target:o,rel:a,className:c,...l}=t;return r.createElement(i.m$.a,{...l,ref:e,className:(0,s.cx)("chakra-linkbox__overlay",c),rel:n?"noopener noreferrer":a,target:n?"_blank":o,__css:{position:"static","&::before":{content:"''",cursor:"inherit",display:"block",position:"absolute",top:0,left:0,zIndex:0,width:"100%",height:"100%"}}})})),(0,i.Gp)((function(t,e){const{className:n,...o}=t;return r.createElement(i.m$.div,{ref:e,position:"relative",...o,className:(0,s.cx)("chakra-linkbox",n),__css:{"a[href]:not(.chakra-linkbox__overlay), abbr[title]":{position:"relative",zIndex:1}}})}));var[v,w]=(0,f.k)({name:"ListStylesContext",errorMessage:"useListStyles returned is 'undefined'. Seems you forgot to wrap the components in \"<List />\" "}),k=(0,i.Gp)((function(t,e){const n=(0,i.jC)("List",t),{children:o,styleType:a="none",stylePosition:s,spacing:l,...u}=(0,c.Lr)(t),f=d(o),p=l?{"& > *:not(style) ~ *:not(style)":{mt:l}}:{};return r.createElement(v,{value:n},r.createElement(i.m$.ul,{ref:e,listStyleType:a,listStylePosition:s,role:"list",__css:{...n.container,...p},...u},f))}));k.displayName="List",(0,i.Gp)(((t,e)=>{const{as:n,...i}=t;return r.createElement(k,{ref:e,as:"ol",styleType:"decimal",marginStart:"1em",...i})})).displayName="OrderedList",(0,i.Gp)((function(t,e){const{as:n,...i}=t;return r.createElement(k,{ref:e,as:"ul",styleType:"initial",marginStart:"1em",...i})})).displayName="UnorderedList",(0,i.Gp)((function(t,e){const n=w();return r.createElement(i.m$.li,{ref:e,...t,__css:n.item})})).displayName="ListItem",(0,i.Gp)((function(t,e){const n=w();return r.createElement(u.JO,{ref:e,role:"presentation",...t,__css:n.icon})})).displayName="ListIcon";var _=(0,i.Gp)((function(t,e){const{columns:n,spacingX:o,spacingY:s,spacing:c,minChildWidth:l,...u}=t,f=(0,i.Fg)(),d=l?function(t,e){return a(t,(t=>{const n=(0,i.LP)("sizes",t,"number"===typeof(r=t)?`${r}px`:r)(e);var r;return null===t?null:`repeat(auto-fit, minmax(${n}, 1fr))`}))}(l,f):a(n,(t=>null===t?null:`repeat(${t}, minmax(0, 1fr))`));return r.createElement(g,{ref:e,gap:c,columnGap:o,rowGap:s,templateColumns:d,...u})}));_.displayName="SimpleGrid",(0,i.m$)("div",{baseStyle:{flex:1,justifySelf:"stretch",alignSelf:"stretch"}}).displayName="Spacer";var E="& > *:not(style) ~ *:not(style)";var O=t=>r.createElement(i.m$.div,{className:"chakra-stack__item",...t,__css:{display:"inline-block",flex:"0 0 auto",minWidth:0,...t.__css}});O.displayName="StackItem";var S=(0,i.Gp)(((t,e)=>{const{isInline:n,direction:o,align:c,justify:l,spacing:u="0.5rem",wrap:f,children:p,divider:h,className:m,shouldWrapChildren:y,...g}=t,b=n?"row":o??"column",x=(0,r.useMemo)((()=>function(t){const{spacing:e,direction:n}=t,r={column:{marginTop:e,marginEnd:0,marginBottom:0,marginStart:0},row:{marginTop:0,marginEnd:0,marginBottom:0,marginStart:e},"column-reverse":{marginTop:0,marginEnd:0,marginBottom:e,marginStart:0},"row-reverse":{marginTop:0,marginEnd:e,marginBottom:0,marginStart:0}};return{flexDirection:n,[E]:a(n,(t=>r[t]))}}({direction:b,spacing:u})),[b,u]),v=(0,r.useMemo)((()=>function(t){const{spacing:e,direction:n}=t,r={column:{my:e,mx:0,borderLeftWidth:0,borderBottomWidth:"1px"},"column-reverse":{my:e,mx:0,borderLeftWidth:0,borderBottomWidth:"1px"},row:{mx:e,my:0,borderLeftWidth:"1px",borderBottomWidth:0},"row-reverse":{mx:e,my:0,borderLeftWidth:"1px",borderBottomWidth:0}};return{"&":a(n,(t=>r[t]))}}({spacing:u,direction:b})),[u,b]),w=!!h,k=!y&&!w,_=(0,r.useMemo)((()=>{const t=d(p);return k?t:t.map(((e,n)=>{const i="undefined"!==typeof e.key?e.key:n,o=n+1===t.length,a=y?r.createElement(O,{key:i},e):e;if(!w)return a;const s=(0,r.cloneElement)(h,{__css:v}),c=o?null:s;return r.createElement(r.Fragment,{key:i},a,c)}))}),[h,v,w,k,y,p]),S=(0,s.cx)("chakra-stack",m);return r.createElement(i.m$.div,{ref:e,display:"flex",alignItems:c,justifyContent:l,flexDirection:x.flexDirection,flexWrap:f,className:S,__css:w?{}:{[E]:x[E]},...g},_)}));S.displayName="Stack",(0,i.Gp)(((t,e)=>r.createElement(S,{align:"center",...t,direction:"row",ref:e}))).displayName="HStack";(0,i.Gp)(((t,e)=>r.createElement(S,{align:"center",...t,direction:"column",ref:e}))).displayName="VStack";var C=(0,i.Gp)((function(t,e){const n=(0,i.mq)("Text",t),{className:o,align:a,decoration:u,casing:f,...d}=(0,c.Lr)(t),p=l({textAlign:t.align,textDecoration:t.decoration,textTransform:t.casing});return r.createElement(i.m$.p,{ref:e,className:(0,s.cx)("chakra-text",t.className),...p,...d,__css:n})}));function R(t){return"number"===typeof t?`${t}px`:t}C.displayName="Text",(0,i.Gp)((function(t,e){const{spacing:n="0.5rem",spacingX:o,spacingY:l,children:u,justify:f,direction:d,align:p,className:h,shouldWrapChildren:m,...y}=t,g=(0,r.useMemo)((()=>{const{spacingX:t=n,spacingY:e=n}={spacingX:o,spacingY:l};return{"--chakra-wrap-x-spacing":e=>a(t,(t=>R((0,c.fr)("space",t)(e)))),"--chakra-wrap-y-spacing":t=>a(e,(e=>R((0,c.fr)("space",e)(t)))),"--wrap-x-spacing":"calc(var(--chakra-wrap-x-spacing) / 2)","--wrap-y-spacing":"calc(var(--chakra-wrap-y-spacing) / 2)",display:"flex",flexWrap:"wrap",justifyContent:f,alignItems:p,flexDirection:d,listStyleType:"none",padding:"0",margin:"calc(var(--wrap-y-spacing) * -1) calc(var(--wrap-x-spacing) * -1)","& > *:not(style)":{margin:"var(--wrap-y-spacing) var(--wrap-x-spacing)"}}}),[n,o,l,f,p,d]),b=(0,r.useMemo)((()=>m?r.Children.map(u,((t,e)=>r.createElement(T,{key:e},t))):u),[u,m]);return r.createElement(i.m$.div,{ref:e,className:(0,s.cx)("chakra-wrap",h),overflow:"hidden",...y},r.createElement(i.m$.ul,{className:"chakra-wrap__list",__css:g},b))})).displayName="Wrap";var T=(0,i.Gp)((function(t,e){const{className:n,...o}=t;return r.createElement(i.m$.li,{ref:e,__css:{display:"flex",alignItems:"flex-start"},className:(0,s.cx)("chakra-wrap__listitem",n),...o})}));T.displayName="WrapItem"},1197:function(t,e,n){"use strict";n.d(e,{UO:function(){return b}});var r=n(7294),i=n(1190),o=n(3747),a=(...t)=>t.filter(Boolean).join(" ");var s={ease:[.25,.1,.25,1],easeIn:[.4,0,1,1],easeOut:[0,0,.2,1],easeInOut:[.4,0,.2,1]},c={position:{left:0,top:0,bottom:0,width:"100%"},enter:{x:0,y:0},exit:{x:"-100%",y:0}},l={position:{right:0,top:0,bottom:0,width:"100%"},enter:{x:0,y:0},exit:{x:"100%",y:0}},u={position:{top:0,left:0,right:0,maxWidth:"100vw"},enter:{x:0,y:0},exit:{x:0,y:"-100%"}},f={position:{bottom:0,left:0,right:0,maxWidth:"100vw"},enter:{x:0,y:0},exit:{x:0,y:"100%"}};function d(t){switch((null==t?void 0:t.direction)??"right"){case"right":default:return l;case"left":return c;case"bottom":return f;case"top":return u}}var p={enter:{duration:.2,ease:s.easeOut},exit:{duration:.1,ease:s.easeIn}},h=(t,e)=>({...t,delay:"number"===typeof e?e:null==e?void 0:e.enter}),m=(t,e)=>({...t,delay:"number"===typeof e?e:null==e?void 0:e.exit}),y={exit:{height:{duration:.2,ease:s.ease},opacity:{duration:.3,ease:s.ease}},enter:{height:{duration:.3,ease:s.ease},opacity:{duration:.4,ease:s.ease}}},g={exit:({animateOpacity:t,startingHeight:e,transition:n,transitionEnd:r,delay:i})=>{return{...t&&{opacity:(o=e,null!=o&&parseInt(o.toString(),10)>0?1:0)},height:e,transitionEnd:null==r?void 0:r.exit,transition:(null==n?void 0:n.exit)??m(y.exit,i)};var o},enter:({animateOpacity:t,endingHeight:e,transition:n,transitionEnd:r,delay:i})=>({...t&&{opacity:1},height:e,transitionEnd:null==r?void 0:r.enter,transition:(null==n?void 0:n.enter)??h(y.enter,i)})},b=(0,r.forwardRef)(((t,e)=>{const{in:n,unmountOnExit:s,animateOpacity:c=!0,startingHeight:l=0,endingHeight:u="auto",style:f,className:d,transition:p,transitionEnd:h,...m}=t,[y,b]=(0,r.useState)(!1);(0,r.useEffect)((()=>{const t=setTimeout((()=>{b(!0)}));return()=>clearTimeout(t)}),[]),(t=>{const{condition:e,message:n}=t})({condition:Boolean(l>0&&s),message:"startingHeight and unmountOnExit are mutually exclusive. You can't use them together"});const x=parseFloat(l.toString())>0,v={startingHeight:l,endingHeight:u,animateOpacity:c,transition:y?p:{enter:{duration:0}},transitionEnd:{enter:null==h?void 0:h.enter,exit:s?null==h?void 0:h.exit:{...null==h?void 0:h.exit,display:x?"block":"none"}}},w=!s||n,k=n||s?"enter":"exit";return r.createElement(i.M,{initial:!1,custom:v},w&&r.createElement(o.E.div,{ref:e,...m,className:a("chakra-collapse",d),style:{overflow:"hidden",display:"block",...f},custom:v,variants:g,initial:!!s&&"exit",animate:k,exit:"exit"}))}));b.displayName="Collapse";var x={initial:"exit",animate:"enter",exit:"exit",variants:{enter:({transition:t,transitionEnd:e,delay:n}={})=>({opacity:1,transition:(null==t?void 0:t.enter)??h(p.enter,n),transitionEnd:null==e?void 0:e.enter}),exit:({transition:t,transitionEnd:e,delay:n}={})=>({opacity:0,transition:(null==t?void 0:t.exit)??m(p.exit,n),transitionEnd:null==e?void 0:e.exit})}};(0,r.forwardRef)((function(t,e){const{unmountOnExit:n,in:s,className:c,transition:l,transitionEnd:u,delay:f,...d}=t,p=s||n?"enter":"exit",h=!n||s&&n,m={transition:l,transitionEnd:u,delay:f};return r.createElement(i.M,{custom:m},h&&r.createElement(o.E.div,{ref:e,className:a("chakra-fade",c),custom:m,...x,animate:p,...d}))})).displayName="Fade";var v={initial:"exit",animate:"enter",exit:"exit",variants:{exit:({reverse:t,initialScale:e,transition:n,transitionEnd:r,delay:i})=>({opacity:0,...t?{scale:e,transitionEnd:null==r?void 0:r.exit}:{transitionEnd:{scale:e,...null==r?void 0:r.exit}},transition:(null==n?void 0:n.exit)??m(p.exit,i)}),enter:({transitionEnd:t,transition:e,delay:n})=>({opacity:1,scale:1,transition:(null==e?void 0:e.enter)??h(p.enter,n),transitionEnd:null==t?void 0:t.enter})}};(0,r.forwardRef)((function(t,e){const{unmountOnExit:n,in:s,reverse:c=!0,initialScale:l=.95,className:u,transition:f,transitionEnd:d,delay:p,...h}=t,m=!n||s&&n,y=s||n?"enter":"exit",g={initialScale:l,reverse:c,transition:f,transitionEnd:d,delay:p};return r.createElement(i.M,{custom:g},m&&r.createElement(o.E.div,{ref:e,className:a("chakra-offset-slide",u),...v,animate:y,custom:g,...h}))})).displayName="ScaleFade";var w={exit:{duration:.15,ease:s.easeInOut},enter:{type:"spring",damping:25,stiffness:180}},k={exit:({direction:t,transition:e,transitionEnd:n,delay:r})=>{const{exit:i}=d({direction:t});return{...i,transition:(null==e?void 0:e.exit)??m(w.exit,r),transitionEnd:null==n?void 0:n.exit}},enter:({direction:t,transitionEnd:e,transition:n,delay:r})=>{const{enter:i}=d({direction:t});return{...i,transition:(null==n?void 0:n.enter)??h(w.enter,r),transitionEnd:null==e?void 0:e.enter}}};(0,r.forwardRef)((function(t,e){const{direction:n="right",style:s,unmountOnExit:c,in:l,className:u,transition:f,transitionEnd:p,delay:h,motionProps:m,...y}=t,g=d({direction:n}),b=Object.assign({position:"fixed"},g.position,s),x=!c||l&&c,v=l||c?"enter":"exit",w={transitionEnd:p,transition:f,direction:n,delay:h};return r.createElement(i.M,{custom:w},x&&r.createElement(o.E.div,{...y,ref:e,initial:"exit",className:a("chakra-slide",u),animate:v,exit:"exit",custom:w,variants:k,style:b,...m}))})).displayName="Slide";var _={initial:"initial",animate:"enter",exit:"exit",variants:{initial:({offsetX:t,offsetY:e,transition:n,transitionEnd:r,delay:i})=>({opacity:0,x:t,y:e,transition:(null==n?void 0:n.exit)??m(p.exit,i),transitionEnd:null==r?void 0:r.exit}),enter:({transition:t,transitionEnd:e,delay:n})=>({opacity:1,x:0,y:0,transition:(null==t?void 0:t.enter)??h(p.enter,n),transitionEnd:null==e?void 0:e.enter}),exit:({offsetY:t,offsetX:e,transition:n,transitionEnd:r,reverse:i,delay:o})=>{const a={x:e,y:t};return{opacity:0,transition:(null==n?void 0:n.exit)??m(p.exit,o),...i?{...a,transitionEnd:null==r?void 0:r.exit}:{transitionEnd:{...a,...null==r?void 0:r.exit}}}}}};(0,r.forwardRef)((function(t,e){const{unmountOnExit:n,in:s,reverse:c=!0,className:l,offsetX:u=0,offsetY:f=8,transition:d,transitionEnd:p,delay:h,...m}=t,y=!n||s&&n,g=s||n?"enter":"exit",b={offsetX:u,offsetY:f,reverse:c,transition:d,transitionEnd:p,delay:h};return r.createElement(i.M,{custom:b},y&&r.createElement(o.E.div,{ref:e,className:a("chakra-offset-slide",l),custom:b,..._,animate:g,...m}))})).displayName="SlideFade"},640:function(t,e,n){"use strict";var r=n(1742),i={"text/plain":"Text","text/html":"Url",default:"Text"};t.exports=function(t,e){var n,o,a,s,c,l,u=!1;e||(e={}),n=e.debug||!1;try{if(a=r(),s=document.createRange(),c=document.getSelection(),(l=document.createElement("span")).textContent=t,l.style.all="unset",l.style.position="fixed",l.style.top=0,l.style.clip="rect(0, 0, 0, 0)",l.style.whiteSpace="pre",l.style.webkitUserSelect="text",l.style.MozUserSelect="text",l.style.msUserSelect="text",l.style.userSelect="text",l.addEventListener("copy",(function(r){if(r.stopPropagation(),e.format)if(r.preventDefault(),"undefined"===typeof r.clipboardData){n&&console.warn("unable to use e.clipboardData"),n&&console.warn("trying IE specific stuff"),window.clipboardData.clearData();var o=i[e.format]||i.default;window.clipboardData.setData(o,t)}else r.clipboardData.clearData(),r.clipboardData.setData(e.format,t);e.onCopy&&(r.preventDefault(),e.onCopy(r.clipboardData))})),document.body.appendChild(l),s.selectNodeContents(l),c.addRange(s),!document.execCommand("copy"))throw new Error("copy command was unsuccessful");u=!0}catch(f){n&&console.error("unable to copy using execCommand: ",f),n&&console.warn("trying IE specific stuff");try{window.clipboardData.setData(e.format||"text",t),e.onCopy&&e.onCopy(window.clipboardData),u=!0}catch(f){n&&console.error("unable to copy using clipboardData: ",f),n&&console.error("falling back to prompt"),o=function(t){var e=(/mac os x/i.test(navigator.userAgent)?"\u2318":"Ctrl")+"+C";return t.replace(/#{\s*key\s*}/g,e)}("message"in e?e.message:"Copy to clipboard: #{key}, Enter"),window.prompt(o,t)}}finally{c&&("function"==typeof c.removeRange?c.removeRange(s):c.removeAllRanges()),l&&document.body.removeChild(l),a()}return u}},2703:function(t,e,n){"use strict";var r=n(414);function i(){}function o(){}o.resetWarningCache=i,t.exports=function(){function t(t,e,n,i,o,a){if(a!==r){var s=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw s.name="Invariant Violation",s}}function e(){return t}t.isRequired=t;var n={array:t,bigint:t,bool:t,func:t,number:t,object:t,string:t,symbol:t,any:t,arrayOf:e,element:t,elementType:t,instanceOf:e,node:t,objectOf:e,oneOf:e,oneOfType:e,shape:e,exact:e,checkPropTypes:o,resetWarningCache:i};return n.PropTypes=n,n}},5697:function(t,e,n){t.exports=n(2703)()},414:function(t){"use strict";t.exports="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"},4415:function(t,e){"use strict";var n,r=Symbol.for("react.element"),i=Symbol.for("react.portal"),o=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),s=Symbol.for("react.profiler"),c=Symbol.for("react.provider"),l=Symbol.for("react.context"),u=Symbol.for("react.server_context"),f=Symbol.for("react.forward_ref"),d=Symbol.for("react.suspense"),p=Symbol.for("react.suspense_list"),h=Symbol.for("react.memo"),m=Symbol.for("react.lazy"),y=Symbol.for("react.offscreen");function g(t){if("object"===typeof t&&null!==t){var e=t.$$typeof;switch(e){case r:switch(t=t.type){case o:case s:case a:case d:case p:return t;default:switch(t=t&&t.$$typeof){case u:case l:case f:case m:case h:case c:return t;default:return e}}case i:return e}}}n=Symbol.for("react.module.reference"),e.isFragment=function(t){return g(t)===o}},4954:function(t,e,n){"use strict";t.exports=n(4415)},5376:function(t,e,n){"use strict";n.d(e,{x1:function(){return p}});var r=n(7294),i=n(6775);const o="label";function a(t,e){"function"===typeof t?t(e):t&&(t.current=e)}function s(t,e){t.labels=e}function c(t,e){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:o;const r=[];t.datasets=e.map((e=>{const i=t.datasets.find((t=>t[n]===e[n]));return i&&e.data&&!r.includes(i)?(r.push(i),Object.assign(i,e),i):{...e}}))}function l(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:o;const n={labels:[],datasets:[]};return s(n,t.labels),c(n,t.datasets,e),n}function u(t,e){let{height:n=150,width:o=300,redraw:u=!1,datasetIdKey:f,type:d,data:p,options:h,plugins:m=[],fallbackContent:y,updateMode:g,...b}=t;const x=(0,r.useRef)(null),v=(0,r.useRef)(),w=()=>{x.current&&(v.current=new i.kL(x.current,{type:d,data:l(p,f),options:h&&{...h},plugins:m}),a(e,v.current))},k=()=>{a(e,null),v.current&&(v.current.destroy(),v.current=null)};return(0,r.useEffect)((()=>{var t,e;!u&&v.current&&h&&(t=v.current,e=h,Object.assign(t.options,e))}),[u,h]),(0,r.useEffect)((()=>{!u&&v.current&&s(v.current.config.data,p.labels)}),[u,p.labels]),(0,r.useEffect)((()=>{!u&&v.current&&p.datasets&&c(v.current.config.data,p.datasets,f)}),[u,p.datasets]),(0,r.useEffect)((()=>{v.current&&(u?(k(),setTimeout(w)):v.current.update(g))}),[u,h,p.labels,p.datasets,g]),(0,r.useEffect)((()=>{v.current&&(k(),setTimeout(w))}),[d]),(0,r.useEffect)((()=>(w(),()=>k())),[]),r.createElement("canvas",Object.assign({ref:x,role:"img",height:n,width:o},b),y)}const f=(0,r.forwardRef)(u);function d(t,e){return i.kL.register(e),(0,r.forwardRef)(((e,n)=>r.createElement(f,Object.assign({},e,{ref:n,type:t}))))}const p=d("line",i.ST)},1742:function(t){t.exports=function(){var t=document.getSelection();if(!t.rangeCount)return function(){};for(var e=document.activeElement,n=[],r=0;r<t.rangeCount;r++)n.push(t.getRangeAt(r));switch(e.tagName.toUpperCase()){case"INPUT":case"TEXTAREA":e.blur();break;default:e=null}return t.removeAllRanges(),function(){"Caret"===t.type&&t.removeAllRanges(),t.rangeCount||n.forEach((function(e){t.addRange(e)})),e&&e.focus()}}},2947:function(t,e,n){"use strict";n.d(e,{Ni:function(){return G}});var r=Object.defineProperty,i=Object.getOwnPropertySymbols,o=Object.prototype.hasOwnProperty,a=Object.prototype.propertyIsEnumerable,s=(t,e,n)=>e in t?r(t,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):t[e]=n,c=(t,e)=>{for(var n in e||(e={}))o.call(e,n)&&s(t,n,e[n]);if(i)for(var n of i(e))a.call(e,n)&&s(t,n,e[n]);return t},l=(t,e,n)=>new Promise(((r,i)=>{var o=t=>{try{s(n.next(t))}catch(e){i(e)}},a=t=>{try{s(n.throw(t))}catch(e){i(e)}},s=t=>t.done?r(t.value):Promise.resolve(t.value).then(o,a);s((n=n.apply(t,e)).next())}));function u(){let t=new TextDecoder("utf-8");return{concat(t,e){let n=new Uint8Array(t.length+e.length);return n.set(t),n.set(e,t.length),n},copy(t,e,n){let r=new Uint8Array(n-e);return r.set(t.subarray(e,n)),r},toUtf8String:(e,n,r)=>t.decode(e.subarray(n,r))}}function f(t,e){let n,r,i=null!=e?e:u(),o=!1,a=!1,s=!1;function c(e){let u,f=0;for(n?(u=0===e.length?0:n.length,e=i.concat(n,e)):u=0;u<e.length;){let n=e[u];if(10===n){if(!a){let n=u>0&&13===e[u-1]?u-1:u;if(o)return;if(s=!1===t.next(i.toUtf8String(e,f,n)),f=u+1,s)break}}else 34===n&&(a=!a);u++}if(n=f<e.length?i.copy(e,f,e.length):void 0,s){if(t.useResume)return void t.useResume((()=>{s=!1,c(new Uint8Array(0))}));l.error(new Error("Unable to pause, useResume is not configured!")),s=!1}r&&(r(),r=void 0)}let l={next(t){if(!o)try{return c(t),!s}catch(e){this.error(e)}return!0},error(e){o||(o=!0,t.error(e))},complete(){o||(n&&t.next(i.toUtf8String(n,0,n.length)),o=!0,t.complete())}};return t.useCancellable&&(l.useCancellable=e=>{t.useCancellable&&t.useCancellable({cancel(){e.cancel(),n=void 0,l.complete()},isCancelled:()=>e.isCancelled()})}),t.useResume&&(l.useResume=t=>{r=t}),l}var d=t=>t,p={boolean:t=>""===t?null:"true"===t,unsignedLong:t=>""===t?null:+t,long:t=>""===t?null:+t,double(t){switch(t){case"":return null;case"+Inf":return Number.POSITIVE_INFINITY;case"-Inf":return Number.NEGATIVE_INFINITY;default:return+t}},string:d,base64Binary:d,duration:t=>""===t?null:t,"dateTime:RFC3339":t=>""===t?null:t},h=class{get(t){var e;let n=t[this.index];return(""===n||void 0===n)&&this.defaultValue&&(n=this.defaultValue),(null!=(e=p[this.dataType])?e:d)(n)}},m=Object.freeze({label:"",dataType:"",group:!1,defaultValue:"",index:Number.MAX_SAFE_INTEGER,get:()=>{}});var y=[404,408,425,429,500,502,503,504];var g=class extends Error{constructor(t){super(t),this.name="IllegalArgumentError",Object.setPrototypeOf(this,g.prototype)}},b=class extends Error{constructor(t,e,n,r,i,o){if(super(),this.statusCode=t,this.statusMessage=e,this.body=n,this.contentType=i,Object.setPrototypeOf(this,b.prototype),o)this.message=o;else if(n){if(null!=i&&i.startsWith("application/json"))try{this.json=JSON.parse(n),this.message=this.json.message,this.code=this.json.code}catch(a){}this.message||(this.message=`${t} ${e} : ${n}`)}else this.message=`${t} ${e}`;this.name="HttpError",this.setRetryAfter(r)}setRetryAfter(t){"string"==typeof t&&/^[0-9]+$/.test(t)?this._retryAfter=parseInt(t):this._retryAfter=0}canRetry(){return t=this.statusCode,y.includes(t);var t}retryAfter(){return this._retryAfter}};var x=class extends Error{constructor(){super(),Object.setPrototypeOf(this,x.prototype),this.name="RequestTimedOutError",this.message="Request timed out"}canRetry(){return!0}retryAfter(){return 0}},v=class extends Error{constructor(){super(),this.name="AbortError",Object.setPrototypeOf(this,v.prototype),this.message="Response aborted"}canRetry(){return!0}retryAfter(){return 0}};function w(t){return new class{constructor(t){t.forEach(((t,e)=>t.index=e)),this.columns=t}column(t,e=!0){for(let n=0;n<this.columns.length;n++){let e=this.columns[n];if(e.label===t)return e}if(e)throw new g(`Column ${t} not found!`);return m}toObject(t){let e={};for(let n=0;n<this.columns.length&&n<t.length;n++){let r=this.columns[n];e[r.label]=r.get(t)}return e}get(t,e){return this.column(e,!1).get(t)}}(t)}function k(t){let e,n,r=(new class{constructor(){this._reuse=!1}get reuse(){return this._reuse}set reuse(t){t&&!this.reusedValues&&(this.reusedValues=new Array(10)),this._reuse=t}withReuse(){return this.reuse=!0,this}splitLine(t){if(null==t)return this.lastSplitLength=0,[];let e=0,n=0,r=this._reuse?this.reusedValues:[],i=0;for(let a=0;a<t.length;a++){let o=t[a];if(","===o){if(e%2===0){let o=this.getValue(t,n,a,e);this._reuse?r[i++]=o:r.push(o),n=a+1,e=0}}else'"'===o&&e++}let o=this.getValue(t,n,t.length,e);return this._reuse?(r[i]=o,this.lastSplitLength=i+1):(r.push(o),this.lastSplitLength=r.length),r}getValue(t,e,n,r){return e===t.length?"":0===r?t.substring(e,n):2===r?t.substring(e+1,n-1):t.substring(e+1,n-1).replace(/""/gi,'"')}}).withReuse(),i=!0,o=0,a={error(e){t.error(e)},next(a){if(""===a)i=!0,e=void 0;else{let s=r.splitLine(a),c=r.lastSplitLength;if(!i)return t.next(s.slice(o,c),n);if(!e){e=new Array(c);for(let t=0;t<c;t++)e[t]=new h}if(s[0].startsWith("#")){if("#datatype"===s[0])for(let t=1;t<c;t++)e[t].dataType=s[t];else if("#default"===s[0])for(let t=1;t<c;t++)e[t].defaultValue=s[t];else if("#group"===s[0])for(let t=1;t<c;t++)e[t].group="t"===s[t][0]}else{""===s[0]?(o=1,e=e.slice(1)):o=0;for(let t=o;t<c;t++)e[t-o].label=s[t];n=w(e),i=!1}}return!0},complete(){t.complete()}};return t.useCancellable&&(a.useCancellable=t.useCancellable.bind(t)),t.useResume&&(a.useResume=t.useResume.bind(t)),a}var _="function"==typeof Symbol&&Symbol.observable||"@@observable";function E(){}var O=class{constructor(t,e){this.executor=t,this.decorator=e}subscribe(t,e,n){let r=function(t){let{next:e,error:n,complete:r}=t;return{next:e?e.bind(t):E,error:n?n.bind(t):E,complete:r?r.bind(t):E}}("object"!=typeof t||null===t?{next:t,error:e,complete:n}:t);return new class{constructor(t,e){this.isClosed=!1;try{e({next:e=>{t.next(e)},error:e=>{this.isClosed=!0,t.error(e)},complete:()=>{this.isClosed=!0,t.complete()},useCancellable:t=>{this.cancellable=t}})}catch(n){this.isClosed=!0,t.error(n)}}get closed(){return this.isClosed}unsubscribe(){var t;null==(t=this.cancellable)||t.cancel(),this.isClosed=!0}}(this.decorator(r),this.executor)}[_](){return this}};Symbol.observable;var S={retryJitter:200,minRetryDelay:5e3,maxRetryDelay:125e3,exponentialBase:5,randomRetry:!0},C={batchSize:1e3,maxBatchBytes:5e7,flushInterval:6e4,writeFailed:function(){},writeSuccess:function(){},writeRetrySkipped:function(){},maxRetries:5,maxRetryTime:18e4,maxBufferLines:32e3,retryJitter:200,minRetryDelay:5e3,maxRetryDelay:125e3,exponentialBase:2,gzipThreshold:1e3,randomRetry:!0};function R(t,e){return function(n){let r="",i=0,o=0;for(;o<n.length;){let a=t.indexOf(n[o]);a>=0&&(r+=n.substring(i,o),r+=e[a],i=o+1),o++}return 0==i?n:(i<n.length&&(r+=n.substring(i,n.length)),r)}}R(", \n\r\t",["\\,","\\ ","\\n","\\r","\\t"]),function(t,e){let n=R(t,e)}('"\\',['\\"',"\\\\"]),R(", =\n\r\t",["\\,","\\ ","\\=","\\n","\\r","\\t"]);var T="000000000";var M=Date.now(),F=0;function N(){{let t=Date.now();t!==M?(M=t,F=0):F++;let e=String(F);return String(t)+T.substr(0,6-e.length)+e}}function I(){return String(Date.now())+T.substr(0,3)}function P(){return String(Date.now())}function j(){return String(Math.floor(Date.now()/1e3))}var D={s:j,ms:P,us:I,ns:N,seconds:j,millis:P,micros:I,nanos:N},A={s:t=>`${Math.floor(t.getTime()/1e3)}`,ms:t=>`${t.getTime()}`,us:t=>`${t.getTime()}000`,ns:t=>`${t.getTime()}000000`};var B={error(t,e){console.error("ERROR: "+t,e||"")},warn(t,e){console.warn("WARN: "+t,e||"")}},L={error(t,e){B.error(t,e)},warn(t,e){B.warn(t,e)}};Symbol("FLUX_VALUE");function $(t){return new class{constructor(t){this.options=c(c({},S),t),this.success()}nextDelay(t,e){let n=function(t,e){if(t){let n;return"function"==typeof t.retryAfter?t.retryAfter():(n=0,e&&e>0?n+Math.round(Math.random()*e):n)}return 0}(t);if(n&&n>0)return n+Math.round(Math.random()*this.options.retryJitter);if(e&&e>0){if(this.options.randomRetry){let t=Math.max(this.options.minRetryDelay,1),n=t*this.options.exponentialBase;for(let r=1;r<e;r++)if(t=n,n*=this.options.exponentialBase,n>=this.options.maxRetryDelay){n=this.options.maxRetryDelay;break}return t+Math.round(Math.random()*(n-t)+Math.random()*this.options.retryJitter)}let t=Math.max(this.options.minRetryDelay,1);for(let n=1;n<e;n++)if(t*=this.options.exponentialBase,t>=this.options.maxRetryDelay){t=this.options.maxRetryDelay;break}return t+Math.round(Math.random()*this.options.retryJitter)}return this.currentDelay?this.currentDelay=Math.min(Math.max(this.currentDelay*this.options.exponentialBase,1)+Math.round(Math.random()*this.options.retryJitter),this.options.maxRetryDelay):this.currentDelay=this.options.minRetryDelay+Math.round(Math.random()*this.options.retryJitter),this.currentDelay}success(){this.currentDelay=void 0}}(t)}function Y(t){let e,n=t,r=t;for(;r.next;)r.next.expires<n.expires&&(e=r,n=r.next),r=r.next;return[n,e]}function W(t){let e={};return t.headers.forEach(((t,n)=>{let r=e[n];void 0===r?e[n]=t:Array.isArray(r)?r.push(t):e[n]=[r,t]})),e}var z={header:!0,delimiter:",",quoteChar:'"',commentPrefix:"#",annotations:["datatype","group","default"]},V=class{constructor(t,e,n){this.transport=t,this.createCSVResponse=e,this.options="string"==typeof n?{org:n}:n}with(t){return new V(this.transport,this.createCSVResponse,c(c({},this.options),t))}response(t){return this.createCSVResponse(this.createExecutor(t))}lines(t){return this.response(t).lines()}rows(t){return this.response(t).rows()}queryLines(t,e){return this.response(t).consumeLines(e)}queryRows(t,e){return this.response(t).consumeRows(e)}collectRows(t,e){return this.response(t).collectRows(e)}collectLines(t){return this.response(t).collectLines()}queryRaw(t){let{org:e,type:n,gzip:r,headers:i}=this.options;return this.transport.request(`/api/v2/query?org=${encodeURIComponent(e)}`,JSON.stringify(this.decorateRequest({query:t.toString(),dialect:z,type:n})),{method:"POST",headers:c({accept:"text/csv","accept-encoding":r?"gzip":"identity","content-type":"application/json; encoding=utf-8"},i)})}createExecutor(t){let{org:e,type:n,gzip:r,headers:i}=this.options;return o=>{this.transport.send(`/api/v2/query?org=${encodeURIComponent(e)}`,JSON.stringify(this.decorateRequest({query:t.toString(),dialect:z,type:n})),{method:"POST",headers:c({"content-type":"application/json; encoding=utf-8","accept-encoding":r?"gzip":"identity"},i)},o)}}decorateRequest(t){var e;return"function"==typeof this.options.now&&(t.now=this.options.now()),t.type=null!=(e=this.options.type)?e:"flux",t}},X=V;function H(t,e){return e.toObject(t)}var G=class{constructor(t){var e;if("string"==typeof t)this._options={url:t};else{if(null===t||"object"!=typeof t)throw new g("No url or configuration specified!");this._options=t}let n=this._options.url;if("string"!=typeof n)throw new g("No url specified!");n.endsWith("/")&&(this._options.url=n.substring(0,n.length-1)),this.transport=null!=(e=this._options.transport)?e:new class{constructor(t){this.connectionOptions=t,this.chunkCombiner=u(),this.requestDecorator=function(){},this.defaultHeaders=c({"content-type":"application/json; charset=utf-8"},t.headers),this.connectionOptions.token&&(this.defaultHeaders.Authorization="Token "+this.connectionOptions.token),this.url=String(this.connectionOptions.url),this.url.endsWith("/")&&(this.url=this.url.substring(0,this.url.length-1)),this.url.endsWith("/api/v2")&&(this.url=this.url.substring(0,this.url.length-7),L.warn(`Please remove '/api/v2' context path from InfluxDB base url, using ${this.url} !`))}send(t,e,n,r){let i,o=function(t={}){let e=0,n={next:n=>{if(0===e&&t.next&&null!==n&&void 0!==n)return t.next(n)},error:n=>{0===e&&(e=1,t.error&&t.error(n))},complete:()=>{0===e&&(e=2,t.complete&&t.complete())},responseStarted:(e,n)=>{t.responseStarted&&t.responseStarted(e,n)}};return t.useCancellable&&(n.useCancellable=t.useCancellable.bind(t)),t.useResume&&(n.useResume=t.useResume.bind(t)),n}(r),a=!1,s=n.signal,u=()=>{},f=u;if(r&&r.useCancellable){let t=new AbortController;s||(s=t.signal,n=c(c({},n),s)),s.addEventListener("abort",(()=>{f()})),r.useCancellable({cancel(){a=!0,t.abort()},isCancelled:()=>a||s.aborted})}this.fetch(t,e,n).then((t=>l(this,null,(function*(){if(null!=r&&r.responseStarted&&o.responseStarted(W(t),t.status),t.status>=300)return t.text().then((e=>{if(!e){let n=t.headers.get("x-influxdb-error");n&&(e=n)}o.error(new b(t.status,t.statusText,e,t.headers.get("retry-after"),t.headers.get("content-type")))})).catch((e=>{L.warn("Unable to receive error body",e),o.error(new b(t.status,t.statusText,void 0,t.headers.get("retry-after"),t.headers.get("content-type")))}));if(t.body){let e,n=t.body.getReader();do{if(i&&(yield i),a)break;if(e=yield n.read(),!1===o.next(e.value)){let t=o.useResume;if(!t){let t="Unable to pause, useResume is not configured!";return yield n.cancel(t),Promise.reject(new Error(t))}i=new Promise((e=>{f=()=>{e(),i=void 0,f=u},t(f)}))}}while(!e.done)}else if(t.arrayBuffer){let e=yield t.arrayBuffer();o.next(new Uint8Array(e))}else{let e=yield t.text();o.next((new TextEncoder).encode(e))}})))).catch((t=>{a||o.error(t)})).finally((()=>o.complete()))}request(t,e,n,r){return l(this,null,(function*(){var i,o;let a=yield this.fetch(t,e,n),{status:s,headers:c}=a,l=c.get("content-type")||"";if(r&&r(W(a),a.status),s>=300){let t=yield a.text();if(!t){let e=c.get("x-influxdb-error");e&&(t=e)}throw new b(s,a.statusText,t,a.headers.get("retry-after"),a.headers.get("content-type"))}let u=null!=(o=null==(i=n.headers)?void 0:i.accept)?o:l;return u.includes("json")?yield a.json():u.includes("text")||u.startsWith("application/csv")?yield a.text():void 0}))}fetch(t,e,n){let r=n,{method:s,headers:l}=r,u=((t,e)=>{var n={};for(var r in t)o.call(t,r)&&e.indexOf(r)<0&&(n[r]=t[r]);if(null!=t&&i)for(var r of i(t))e.indexOf(r)<0&&a.call(t,r)&&(n[r]=t[r]);return n})(r,["method","headers"]),f=`${this.url}${t}`,d=c(c({method:s,body:"GET"===s||"HEAD"===s?void 0:"string"==typeof e?e:JSON.stringify(e),headers:c(c({},this.defaultHeaders),l),credentials:"omit"},this.connectionOptions.transportOptions),u);return this.requestDecorator(d,n,f),fetch(f,d)}}(this._options),this.processCSVResponse=t=>new class{constructor(t,e){this.executor=t,this.chunkCombiner=e}lines(){return new O(this.executor,(t=>f(t,this.chunkCombiner)))}rows(){return new O(this.executor,(t=>f(k({next(e,n){t.next({values:e,tableMeta:n})},error(e){t.error(e)},complete(){t.complete()}}),this.chunkCombiner)))}consumeLines(t){this.executor(f(t,this.chunkCombiner))}consumeRows(t){this.executor(f(k(t),this.chunkCombiner))}collectRows(t=H){let e=[];return new Promise(((n,r)=>{this.consumeRows({next(n,r){let i=t.call(this,n,r);void 0!==i&&e.push(i)},error(t){r(t)},complete(){n(e)}})}))}collectLines(){let t=[];return new Promise(((e,n)=>{this.consumeLines({next(e){t.push(e)},error(t){n(t)},complete(){e(t)}})}))}}(t,this.transport.chunkCombiner)}getWriteApi(t,e,n="ns",r){return new class{constructor(t,e,n,r,i){this.transport=t,this.closed=!1,this._timeoutHandle=void 0,this.path=`/api/v2/write?org=${encodeURIComponent(e)}&bucket=${encodeURIComponent(n)}&precision=${r}`,null!=i&&i.consistency&&(this.path+=`&consistency=${encodeURIComponent(i.consistency)}`),this.writeOptions=c(c({},C),i),this.currentTime=D[r],this.dateToProtocolTimestamp=A[r],this.writeOptions.defaultTags&&this.useDefaultTags(this.writeOptions.defaultTags),this.sendOptions={method:"POST",headers:c({"content-type":"text/plain; charset=utf-8"},null==i?void 0:i.headers),gzipThreshold:this.writeOptions.gzipThreshold},this.writeBuffer=new class{constructor(t,e,n,r){this.maxChunkRecords=t,this.maxBatchBytes=e,this.flushFn=n,this.scheduleSend=r,this.length=0,this.bytes=-1,this.lines=new Array(t)}add(t){let e=function(t){let e=t.length;for(let n=0;n<t.length;n++){let r=t.charCodeAt(n);r<128||(r>=128&&r<=2047?e++:r>=2048&&r<=65535?r>=55296&&r<=57343?e++:e+=2:e+=3)}return e}(t);0===this.length?this.scheduleSend():this.bytes+e+1>=this.maxBatchBytes&&this.flush().catch((t=>{})),this.lines[this.length]=t,this.length++,this.bytes+=e+1,(this.length>=this.maxChunkRecords||this.bytes>=this.maxBatchBytes)&&this.flush().catch((t=>{}))}flush(){let t=this.reset();return t.length>0?this.flushFn(t):Promise.resolve()}reset(){let t=this.lines.slice(0,this.length);return this.length=0,this.bytes=-1,t}}(this.writeOptions.batchSize,this.writeOptions.maxBatchBytes,(t=>(this._clearFlushTimeout(),this.sendBatch(t,this.writeOptions.maxRetries))),(()=>{this.writeOptions.flushInterval>0&&(this._clearFlushTimeout(),this.closed||(this._timeoutHandle=setTimeout((()=>this.sendBatch(this.writeBuffer.reset(),this.writeOptions.maxRetries).catch((t=>{}))),this.writeOptions.flushInterval)))})),this.sendBatch=this.sendBatch.bind(this),this.retryStrategy=$(this.writeOptions),this.retryBuffer=new class{constructor(t,e,n=(()=>{})){this.maxLines=t,this.retryLines=e,this.onShrink=n,this.size=0,this.closed=!1,this._timeoutHandle=void 0}addLines(t,e,n,r){if(this.closed||!t.length)return;let i=Date.now()+n;if(r<i&&(i=r),this.first&&this.size+t.length>this.maxLines){let e=this.size,n=.7*e;do{let[t,e]=Y(this.first);this.size-=t.lines.length,e?e.next=t.next:(this.first=t.next,this.first&&this.scheduleRetry(this.first.retryTime-Date.now())),t.next=void 0,this.onShrink(t)}while(this.first&&this.size+t.length>n);L.error(`RetryBuffer: ${e-this.size} oldest lines removed to keep buffer size under the limit of ${this.maxLines} lines.`)}let o,a={lines:t,retryCount:e,retryTime:i,expires:r},s=this.first;for(;;){if(!s||s.retryTime>i){a.next=s,o?o.next=a:(this.first=a,this.scheduleRetry(i-Date.now()));break}o=s,s=s.next}this.size+=t.length}removeLines(){if(this.first){let t=this.first;return this.first=this.first.next,t.next=void 0,this.size-=t.lines.length,t}}scheduleRetry(t){this._timeoutHandle&&clearTimeout(this._timeoutHandle),this._timeoutHandle=setTimeout((()=>{let t=this.removeLines();t?this.retryLines(t.lines,t.retryCount,t.expires).catch((()=>{})).finally((()=>{this.first&&this.scheduleRetry(this.first.retryTime-Date.now())})):this._timeoutHandle=void 0}),Math.max(t,0))}flush(){return l(this,null,(function*(){let t;for(;t=this.removeLines();)yield this.retryLines(t.lines,t.retryCount,t.expires)}))}close(){return this._timeoutHandle&&(clearTimeout(this._timeoutHandle),this._timeoutHandle=void 0),this.closed=!0,this.size}}(this.writeOptions.maxBufferLines,this.sendBatch,this.writeOptions.writeRetrySkipped)}sendBatch(t,e,n=Date.now()+this.writeOptions.maxRetryTime){let r=this,i=r.writeOptions.maxRetries+1-e;if(!this.closed&&t.length>0){if(n<=Date.now()){let e=new Error("Max retry time exceeded.");return r.writeOptions.writeFailed.call(r,e,t,i,n)||(L.error(`Write to InfluxDB failed (attempt: ${i}).`,e),Promise.reject(e))}return new Promise(((o,a)=>{let s,c={responseStarted(t,e){s=e},error(l){let u=r.writeOptions.writeFailed.call(r,l,t,i,n);if(!u)return l instanceof b&&l.json&&"string"==typeof l.json.error&&l.json.error.includes("hinted handoff queue not empty")?(L.warn("Write to InfluxDB returns: "+l.json.error),s=204,void c.complete()):!r.closed&&e>0&&(!(l instanceof b)||l.statusCode>=429)?(L.warn(`Write to InfluxDB failed (attempt: ${i}).`,l),r.retryBuffer.addLines(t,e-1,r.retryStrategy.nextDelay(l,i),n),void a(l)):(L.error("Write to InfluxDB failed.",l),void a(l));u.then(o,a)},complete(){if(204==s||null==s)r.writeOptions.writeSuccess.call(r,t),r.retryStrategy.success(),o();else{let t=`204 HTTP response status code expected, but ${s} returned`,e=new b(s,t,void 0,"0");e.message=t,c.error(e)}}};this.transport.send(this.path,t.join("\n"),this.sendOptions,c)}))}return Promise.resolve()}_clearFlushTimeout(){void 0!==this._timeoutHandle&&(clearTimeout(this._timeoutHandle),this._timeoutHandle=void 0)}writeRecord(t){if(this.closed)throw new Error("writeApi: already closed!");this.writeBuffer.add(t)}writeRecords(t){if(this.closed)throw new Error("writeApi: already closed!");for(let e=0;e<t.length;e++)this.writeBuffer.add(t[e])}writePoint(t){if(this.closed)throw new Error("writeApi: already closed!");let e=t.toLineProtocol(this);e&&this.writeBuffer.add(e)}writePoints(t){if(this.closed)throw new Error("writeApi: already closed!");for(let e=0;e<t.length;e++){let n=t[e].toLineProtocol(this);n&&this.writeBuffer.add(n)}}flush(t){return l(this,null,(function*(){if(yield this.writeBuffer.flush(),t)return yield this.retryBuffer.flush()}))}close(){return this.writeBuffer.flush().finally((()=>{let t=this.retryBuffer.close();t&&L.error(`Retry buffer closed with ${t} items that were not written to InfluxDB!`,null),this.closed=!0}))}dispose(){return this._clearFlushTimeout(),this.closed=!0,this.retryBuffer.close()+this.writeBuffer.length}useDefaultTags(t){return this.defaultTags=t,this}convertTime(t){return void 0===t?this.currentTime():"string"==typeof t?t.length>0?t:void 0:t instanceof Date?this.dateToProtocolTimestamp(t):String("number"==typeof t?Math.floor(t):t)}}(this.transport,t,e,n,null!=r?r:this._options.writeOptions)}getQueryApi(t){return new X(this.transport,this.processCSVResponse,t)}}},7568:function(t,e,n){"use strict";function r(t,e,n,r,i,o,a){try{var s=t[o](a),c=s.value}catch(l){return void n(l)}s.done?e(c):Promise.resolve(c).then(r,i)}function i(t){return function(){var e=this,n=arguments;return new Promise((function(i,o){var a=t.apply(e,n);function s(t){r(a,i,o,s,c,"next",t)}function c(t){r(a,i,o,s,c,"throw",t)}s(void 0)}))}}n.d(e,{Z:function(){return i}})},9217:function(t,e,n){"use strict";var r=n(6775);r.kL.register(...r.zX)},2454:function(t,e,n){"use strict";function r(){}n.d(e,{$:function(){return ye},A:function(){return $},B:function(){return l},C:function(){return p},D:function(){return Ie},E:function(){return Q},F:function(){return H},G:function(){return ue},H:function(){return P},I:function(){return tt},J:function(){return de},K:function(){return Me},L:function(){return ge},M:function(){return we},N:function(){return be},O:function(){return Fe},P:function(){return T},Q:function(){return h},R:function(){return pt},S:function(){return ht},T:function(){return M},U:function(){return oe},V:function(){return x},W:function(){return E},X:function(){return ln},Y:function(){return it},Z:function(){return rt},_:function(){return lt},a:function(){return Ne},a0:function(){return q},a1:function(){return fn},a2:function(){return rn},a3:function(){return hn},a4:function(){return ft},a5:function(){return pn},a6:function(){return nn},a7:function(){return ae},a8:function(){return S},a9:function(){return De},aA:function(){return vn},aB:function(){return wn},aC:function(){return mt},aD:function(){return kn},aE:function(){return me},aF:function(){return r},aG:function(){return U},aH:function(){return V},aI:function(){return L},aJ:function(){return z},aK:function(){return W},aL:function(){return G},aM:function(){return fe},aN:function(){return ot},aO:function(){return nt},aa:function(){return je},ab:function(){return Ae},ac:function(){return v},ad:function(){return i},ae:function(){return dt},af:function(){return dn},ag:function(){return pe},ah:function(){return C},ai:function(){return m},aj:function(){return R},ak:function(){return et},al:function(){return Ce},am:function(){return en},an:function(){return Cn},ao:function(){return Sn},ap:function(){return yn},aq:function(){return gn},ar:function(){return mn},as:function(){return xe},at:function(){return ve},au:function(){return he},av:function(){return _e},aw:function(){return Re},ax:function(){return Te},ay:function(){return On},az:function(){return K},b:function(){return a},c:function(){return re},d:function(){return le},e:function(){return wt},f:function(){return _},g:function(){return c},h:function(){return Pe},i:function(){return s},j:function(){return O},k:function(){return o},l:function(){return st},m:function(){return f},n:function(){return d},o:function(){return xn},p:function(){return Z},q:function(){return yt},r:function(){return ut},s:function(){return B},t:function(){return X},u:function(){return ct},v:function(){return u},w:function(){return gt},x:function(){return Y},y:function(){return qe},z:function(){return A}});const i=function(){let t=0;return function(){return t++}}();function o(t){return null===t||"undefined"===typeof t}function a(t){if(Array.isArray&&Array.isArray(t))return!0;const e=Object.prototype.toString.call(t);return"[object"===e.slice(0,7)&&"Array]"===e.slice(-6)}function s(t){return null!==t&&"[object Object]"===Object.prototype.toString.call(t)}const c=t=>("number"===typeof t||t instanceof Number)&&isFinite(+t);function l(t,e){return c(t)?t:e}function u(t,e){return"undefined"===typeof t?e:t}const f=(t,e)=>"string"===typeof t&&t.endsWith("%")?parseFloat(t)/100:t/e,d=(t,e)=>"string"===typeof t&&t.endsWith("%")?parseFloat(t)/100*e:+t;function p(t,e,n){if(t&&"function"===typeof t.call)return t.apply(n,e)}function h(t,e,n,r){let i,o,c;if(a(t))if(o=t.length,r)for(i=o-1;i>=0;i--)e.call(n,t[i],i);else for(i=0;i<o;i++)e.call(n,t[i],i);else if(s(t))for(c=Object.keys(t),o=c.length,i=0;i<o;i++)e.call(n,t[c[i]],c[i])}function m(t,e){let n,r,i,o;if(!t||!e||t.length!==e.length)return!1;for(n=0,r=t.length;n<r;++n)if(i=t[n],o=e[n],i.datasetIndex!==o.datasetIndex||i.index!==o.index)return!1;return!0}function y(t){if(a(t))return t.map(y);if(s(t)){const e=Object.create(null),n=Object.keys(t),r=n.length;let i=0;for(;i<r;++i)e[n[i]]=y(t[n[i]]);return e}return t}function g(t){return-1===["__proto__","prototype","constructor"].indexOf(t)}function b(t,e,n,r){if(!g(t))return;const i=e[t],o=n[t];s(i)&&s(o)?x(i,o,r):e[t]=y(o)}function x(t,e,n){const r=a(e)?e:[e],i=r.length;if(!s(t))return t;const o=(n=n||{}).merger||b;for(let a=0;a<i;++a){if(!s(e=r[a]))continue;const i=Object.keys(e);for(let r=0,a=i.length;r<a;++r)o(i[r],t,e,n)}return t}function v(t,e){return x(t,e,{merger:w})}function w(t,e,n){if(!g(t))return;const r=e[t],i=n[t];s(r)&&s(i)?v(r,i):Object.prototype.hasOwnProperty.call(e,t)||(e[t]=y(i))}const k={"":t=>t,x:t=>t.x,y:t=>t.y};function _(t,e){const n=k[e]||(k[e]=function(t){const e=function(t){const e=t.split("."),n=[];let r="";for(const i of e)r+=i,r.endsWith("\\")?r=r.slice(0,-1)+".":(n.push(r),r="");return n}(t);return t=>{for(const n of e){if(""===n)break;t=t&&t[n]}return t}}(e));return n(t)}function E(t){return t.charAt(0).toUpperCase()+t.slice(1)}const O=t=>"undefined"!==typeof t,S=t=>"function"===typeof t,C=(t,e)=>{if(t.size!==e.size)return!1;for(const n of t)if(!e.has(n))return!1;return!0};function R(t){return"mouseup"===t.type||"click"===t.type||"contextmenu"===t.type}const T=Math.PI,M=2*T,F=M+T,N=Number.POSITIVE_INFINITY,I=T/180,P=T/2,j=T/4,D=2*T/3,A=Math.log10,B=Math.sign;function L(t){const e=Math.round(t);t=W(t,e,t/1e3)?e:t;const n=Math.pow(10,Math.floor(A(t))),r=t/n;return(r<=1?1:r<=2?2:r<=5?5:10)*n}function $(t){const e=[],n=Math.sqrt(t);let r;for(r=1;r<n;r++)t%r===0&&(e.push(r),e.push(t/r));return n===(0|n)&&e.push(n),e.sort(((t,e)=>t-e)).pop(),e}function Y(t){return!isNaN(parseFloat(t))&&isFinite(t)}function W(t,e,n){return Math.abs(t-e)<n}function z(t,e){const n=Math.round(t);return n-e<=t&&n+e>=t}function V(t,e,n){let r,i,o;for(r=0,i=t.length;r<i;r++)o=t[r][n],isNaN(o)||(e.min=Math.min(e.min,o),e.max=Math.max(e.max,o))}function X(t){return t*(T/180)}function H(t){return t*(180/T)}function G(t){if(!c(t))return;let e=1,n=0;for(;Math.round(t*e)/e!==t;)e*=10,n++;return n}function q(t,e){const n=e.x-t.x,r=e.y-t.y,i=Math.sqrt(n*n+r*r);let o=Math.atan2(r,n);return o<-.5*T&&(o+=M),{angle:o,distance:i}}function U(t,e){return Math.sqrt(Math.pow(e.x-t.x,2)+Math.pow(e.y-t.y,2))}function J(t,e){return(t-e+F)%M-T}function K(t){return(t%M+M)%M}function Z(t,e,n,r){const i=K(t),o=K(e),a=K(n),s=K(o-i),c=K(a-i),l=K(i-o),u=K(i-a);return i===o||i===a||r&&o===a||s>c&&l<u}function Q(t,e,n){return Math.max(e,Math.min(n,t))}function tt(t){return Q(t,-32768,32767)}function et(t,e,n,r=1e-6){return t>=Math.min(e,n)-r&&t<=Math.max(e,n)+r}function nt(t,e,n){n=n||(n=>t[n]<e);let r,i=t.length-1,o=0;for(;i-o>1;)r=o+i>>1,n(r)?o=r:i=r;return{lo:o,hi:i}}const rt=(t,e,n,r)=>nt(t,n,r?r=>t[r][e]<=n:r=>t[r][e]<n),it=(t,e,n)=>nt(t,n,(r=>t[r][e]>=n));function ot(t,e,n){let r=0,i=t.length;for(;r<i&&t[r]<e;)r++;for(;i>r&&t[i-1]>n;)i--;return r>0||i<t.length?t.slice(r,i):t}const at=["push","pop","shift","splice","unshift"];function st(t,e){t._chartjs?t._chartjs.listeners.push(e):(Object.defineProperty(t,"_chartjs",{configurable:!0,enumerable:!1,value:{listeners:[e]}}),at.forEach((e=>{const n="_onData"+E(e),r=t[e];Object.defineProperty(t,e,{configurable:!0,enumerable:!1,value(...e){const i=r.apply(this,e);return t._chartjs.listeners.forEach((t=>{"function"===typeof t[n]&&t[n](...e)})),i}})})))}function ct(t,e){const n=t._chartjs;if(!n)return;const r=n.listeners,i=r.indexOf(e);-1!==i&&r.splice(i,1),r.length>0||(at.forEach((e=>{delete t[e]})),delete t._chartjs)}function lt(t){const e=new Set;let n,r;for(n=0,r=t.length;n<r;++n)e.add(t[n]);return e.size===r?t:Array.from(e)}const ut="undefined"===typeof window?function(t){return t()}:window.requestAnimationFrame;function ft(t,e,n){const r=n||(t=>Array.prototype.slice.call(t));let i=!1,o=[];return function(...n){o=r(n),i||(i=!0,ut.call(window,(()=>{i=!1,t.apply(e,o)})))}}function dt(t,e){let n;return function(...r){return e?(clearTimeout(n),n=setTimeout(t,e,r)):t.apply(this,r),e}}const pt=t=>"start"===t?"left":"end"===t?"right":"center",ht=(t,e,n)=>"start"===t?e:"end"===t?n:(e+n)/2,mt=(t,e,n,r)=>t===(r?"left":"right")?n:"center"===t?(e+n)/2:e;function yt(t,e,n){const r=e.length;let i=0,o=r;if(t._sorted){const{iScale:a,_parsed:s}=t,c=a.axis,{min:l,max:u,minDefined:f,maxDefined:d}=a.getUserBounds();f&&(i=Q(Math.min(rt(s,a.axis,l).lo,n?r:rt(e,c,a.getPixelForValue(l)).lo),0,r-1)),o=d?Q(Math.max(rt(s,a.axis,u,!0).hi+1,n?0:rt(e,c,a.getPixelForValue(u),!0).hi+1),i,r)-i:r-i}return{start:i,count:o}}function gt(t){const{xScale:e,yScale:n,_scaleRanges:r}=t,i={xmin:e.min,xmax:e.max,ymin:n.min,ymax:n.max};if(!r)return t._scaleRanges=i,!0;const o=r.xmin!==e.min||r.xmax!==e.max||r.ymin!==n.min||r.ymax!==n.max;return Object.assign(r,i),o}const bt=t=>0===t||1===t,xt=(t,e,n)=>-Math.pow(2,10*(t-=1))*Math.sin((t-e)*M/n),vt=(t,e,n)=>Math.pow(2,-10*t)*Math.sin((t-e)*M/n)+1,wt={linear:t=>t,easeInQuad:t=>t*t,easeOutQuad:t=>-t*(t-2),easeInOutQuad:t=>(t/=.5)<1?.5*t*t:-.5*(--t*(t-2)-1),easeInCubic:t=>t*t*t,easeOutCubic:t=>(t-=1)*t*t+1,easeInOutCubic:t=>(t/=.5)<1?.5*t*t*t:.5*((t-=2)*t*t+2),easeInQuart:t=>t*t*t*t,easeOutQuart:t=>-((t-=1)*t*t*t-1),easeInOutQuart:t=>(t/=.5)<1?.5*t*t*t*t:-.5*((t-=2)*t*t*t-2),easeInQuint:t=>t*t*t*t*t,easeOutQuint:t=>(t-=1)*t*t*t*t+1,easeInOutQuint:t=>(t/=.5)<1?.5*t*t*t*t*t:.5*((t-=2)*t*t*t*t+2),easeInSine:t=>1-Math.cos(t*P),easeOutSine:t=>Math.sin(t*P),easeInOutSine:t=>-.5*(Math.cos(T*t)-1),easeInExpo:t=>0===t?0:Math.pow(2,10*(t-1)),easeOutExpo:t=>1===t?1:1-Math.pow(2,-10*t),easeInOutExpo:t=>bt(t)?t:t<.5?.5*Math.pow(2,10*(2*t-1)):.5*(2-Math.pow(2,-10*(2*t-1))),easeInCirc:t=>t>=1?t:-(Math.sqrt(1-t*t)-1),easeOutCirc:t=>Math.sqrt(1-(t-=1)*t),easeInOutCirc:t=>(t/=.5)<1?-.5*(Math.sqrt(1-t*t)-1):.5*(Math.sqrt(1-(t-=2)*t)+1),easeInElastic:t=>bt(t)?t:xt(t,.075,.3),easeOutElastic:t=>bt(t)?t:vt(t,.075,.3),easeInOutElastic(t){const e=.1125;return bt(t)?t:t<.5?.5*xt(2*t,e,.45):.5+.5*vt(2*t-1,e,.45)},easeInBack(t){const e=1.70158;return t*t*((e+1)*t-e)},easeOutBack(t){const e=1.70158;return(t-=1)*t*((e+1)*t+e)+1},easeInOutBack(t){let e=1.70158;return(t/=.5)<1?t*t*((1+(e*=1.525))*t-e)*.5:.5*((t-=2)*t*((1+(e*=1.525))*t+e)+2)},easeInBounce:t=>1-wt.easeOutBounce(1-t),easeOutBounce(t){const e=7.5625,n=2.75;return t<1/n?e*t*t:t<2/n?e*(t-=1.5/n)*t+.75:t<2.5/n?e*(t-=2.25/n)*t+.9375:e*(t-=2.625/n)*t+.984375},easeInOutBounce:t=>t<.5?.5*wt.easeInBounce(2*t):.5*wt.easeOutBounce(2*t-1)+.5};function kt(t){return t+.5|0}const _t=(t,e,n)=>Math.max(Math.min(t,n),e);function Et(t){return _t(kt(2.55*t),0,255)}function Ot(t){return _t(kt(255*t),0,255)}function St(t){return _t(kt(t/2.55)/100,0,1)}function Ct(t){return _t(kt(100*t),0,100)}const Rt={0:0,1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,A:10,B:11,C:12,D:13,E:14,F:15,a:10,b:11,c:12,d:13,e:14,f:15},Tt=[..."0123456789ABCDEF"],Mt=t=>Tt[15&t],Ft=t=>Tt[(240&t)>>4]+Tt[15&t],Nt=t=>(240&t)>>4===(15&t);function It(t){var e=(t=>Nt(t.r)&&Nt(t.g)&&Nt(t.b)&&Nt(t.a))(t)?Mt:Ft;return t?"#"+e(t.r)+e(t.g)+e(t.b)+((t,e)=>t<255?e(t):"")(t.a,e):void 0}const Pt=/^(hsla?|hwb|hsv)\(\s*([-+.e\d]+)(?:deg)?[\s,]+([-+.e\d]+)%[\s,]+([-+.e\d]+)%(?:[\s,]+([-+.e\d]+)(%)?)?\s*\)$/;function jt(t,e,n){const r=e*Math.min(n,1-n),i=(e,i=(e+t/30)%12)=>n-r*Math.max(Math.min(i-3,9-i,1),-1);return[i(0),i(8),i(4)]}function Dt(t,e,n){const r=(r,i=(r+t/60)%6)=>n-n*e*Math.max(Math.min(i,4-i,1),0);return[r(5),r(3),r(1)]}function At(t,e,n){const r=jt(t,1,.5);let i;for(e+n>1&&(i=1/(e+n),e*=i,n*=i),i=0;i<3;i++)r[i]*=1-e-n,r[i]+=e;return r}function Bt(t){const e=t.r/255,n=t.g/255,r=t.b/255,i=Math.max(e,n,r),o=Math.min(e,n,r),a=(i+o)/2;let s,c,l;return i!==o&&(l=i-o,c=a>.5?l/(2-i-o):l/(i+o),s=function(t,e,n,r,i){return t===i?(e-n)/r+(e<n?6:0):e===i?(n-t)/r+2:(t-e)/r+4}(e,n,r,l,i),s=60*s+.5),[0|s,c||0,a]}function Lt(t,e,n,r){return(Array.isArray(e)?t(e[0],e[1],e[2]):t(e,n,r)).map(Ot)}function $t(t,e,n){return Lt(jt,t,e,n)}function Yt(t){return(t%360+360)%360}function Wt(t){const e=Pt.exec(t);let n,r=255;if(!e)return;e[5]!==n&&(r=e[6]?Et(+e[5]):Ot(+e[5]));const i=Yt(+e[2]),o=+e[3]/100,a=+e[4]/100;return n="hwb"===e[1]?function(t,e,n){return Lt(At,t,e,n)}(i,o,a):"hsv"===e[1]?function(t,e,n){return Lt(Dt,t,e,n)}(i,o,a):$t(i,o,a),{r:n[0],g:n[1],b:n[2],a:r}}const zt={x:"dark",Z:"light",Y:"re",X:"blu",W:"gr",V:"medium",U:"slate",A:"ee",T:"ol",S:"or",B:"ra",C:"lateg",D:"ights",R:"in",Q:"turquois",E:"hi",P:"ro",O:"al",N:"le",M:"de",L:"yello",F:"en",K:"ch",G:"arks",H:"ea",I:"ightg",J:"wh"},Vt={OiceXe:"f0f8ff",antiquewEte:"faebd7",aqua:"ffff",aquamarRe:"7fffd4",azuY:"f0ffff",beige:"f5f5dc",bisque:"ffe4c4",black:"0",blanKedOmond:"ffebcd",Xe:"ff",XeviTet:"8a2be2",bPwn:"a52a2a",burlywood:"deb887",caMtXe:"5f9ea0",KartYuse:"7fff00",KocTate:"d2691e",cSO:"ff7f50",cSnflowerXe:"6495ed",cSnsilk:"fff8dc",crimson:"dc143c",cyan:"ffff",xXe:"8b",xcyan:"8b8b",xgTMnPd:"b8860b",xWay:"a9a9a9",xgYF:"6400",xgYy:"a9a9a9",xkhaki:"bdb76b",xmagFta:"8b008b",xTivegYF:"556b2f",xSange:"ff8c00",xScEd:"9932cc",xYd:"8b0000",xsOmon:"e9967a",xsHgYF:"8fbc8f",xUXe:"483d8b",xUWay:"2f4f4f",xUgYy:"2f4f4f",xQe:"ced1",xviTet:"9400d3",dAppRk:"ff1493",dApskyXe:"bfff",dimWay:"696969",dimgYy:"696969",dodgerXe:"1e90ff",fiYbrick:"b22222",flSOwEte:"fffaf0",foYstWAn:"228b22",fuKsia:"ff00ff",gaRsbSo:"dcdcdc",ghostwEte:"f8f8ff",gTd:"ffd700",gTMnPd:"daa520",Way:"808080",gYF:"8000",gYFLw:"adff2f",gYy:"808080",honeyMw:"f0fff0",hotpRk:"ff69b4",RdianYd:"cd5c5c",Rdigo:"4b0082",ivSy:"fffff0",khaki:"f0e68c",lavFMr:"e6e6fa",lavFMrXsh:"fff0f5",lawngYF:"7cfc00",NmoncEffon:"fffacd",ZXe:"add8e6",ZcSO:"f08080",Zcyan:"e0ffff",ZgTMnPdLw:"fafad2",ZWay:"d3d3d3",ZgYF:"90ee90",ZgYy:"d3d3d3",ZpRk:"ffb6c1",ZsOmon:"ffa07a",ZsHgYF:"20b2aa",ZskyXe:"87cefa",ZUWay:"778899",ZUgYy:"778899",ZstAlXe:"b0c4de",ZLw:"ffffe0",lime:"ff00",limegYF:"32cd32",lRF:"faf0e6",magFta:"ff00ff",maPon:"800000",VaquamarRe:"66cdaa",VXe:"cd",VScEd:"ba55d3",VpurpN:"9370db",VsHgYF:"3cb371",VUXe:"7b68ee",VsprRggYF:"fa9a",VQe:"48d1cc",VviTetYd:"c71585",midnightXe:"191970",mRtcYam:"f5fffa",mistyPse:"ffe4e1",moccasR:"ffe4b5",navajowEte:"ffdead",navy:"80",Tdlace:"fdf5e6",Tive:"808000",TivedBb:"6b8e23",Sange:"ffa500",SangeYd:"ff4500",ScEd:"da70d6",pOegTMnPd:"eee8aa",pOegYF:"98fb98",pOeQe:"afeeee",pOeviTetYd:"db7093",papayawEp:"ffefd5",pHKpuff:"ffdab9",peru:"cd853f",pRk:"ffc0cb",plum:"dda0dd",powMrXe:"b0e0e6",purpN:"800080",YbeccapurpN:"663399",Yd:"ff0000",Psybrown:"bc8f8f",PyOXe:"4169e1",saddNbPwn:"8b4513",sOmon:"fa8072",sandybPwn:"f4a460",sHgYF:"2e8b57",sHshell:"fff5ee",siFna:"a0522d",silver:"c0c0c0",skyXe:"87ceeb",UXe:"6a5acd",UWay:"708090",UgYy:"708090",snow:"fffafa",sprRggYF:"ff7f",stAlXe:"4682b4",tan:"d2b48c",teO:"8080",tEstN:"d8bfd8",tomato:"ff6347",Qe:"40e0d0",viTet:"ee82ee",JHt:"f5deb3",wEte:"ffffff",wEtesmoke:"f5f5f5",Lw:"ffff00",LwgYF:"9acd32"};let Xt;function Ht(t){Xt||(Xt=function(){const t={},e=Object.keys(Vt),n=Object.keys(zt);let r,i,o,a,s;for(r=0;r<e.length;r++){for(a=s=e[r],i=0;i<n.length;i++)o=n[i],s=s.replace(o,zt[o]);o=parseInt(Vt[a],16),t[s]=[o>>16&255,o>>8&255,255&o]}return t}(),Xt.transparent=[0,0,0,0]);const e=Xt[t.toLowerCase()];return e&&{r:e[0],g:e[1],b:e[2],a:4===e.length?e[3]:255}}const Gt=/^rgba?\(\s*([-+.\d]+)(%)?[\s,]+([-+.e\d]+)(%)?[\s,]+([-+.e\d]+)(%)?(?:[\s,/]+([-+.e\d]+)(%)?)?\s*\)$/;const qt=t=>t<=.0031308?12.92*t:1.055*Math.pow(t,1/2.4)-.055,Ut=t=>t<=.04045?t/12.92:Math.pow((t+.055)/1.055,2.4);function Jt(t,e,n){if(t){let r=Bt(t);r[e]=Math.max(0,Math.min(r[e]+r[e]*n,0===e?360:1)),r=$t(r),t.r=r[0],t.g=r[1],t.b=r[2]}}function Kt(t,e){return t?Object.assign(e||{},t):t}function Zt(t){var e={r:0,g:0,b:0,a:255};return Array.isArray(t)?t.length>=3&&(e={r:t[0],g:t[1],b:t[2],a:255},t.length>3&&(e.a=Ot(t[3]))):(e=Kt(t,{r:0,g:0,b:0,a:1})).a=Ot(e.a),e}function Qt(t){return"r"===t.charAt(0)?function(t){const e=Gt.exec(t);let n,r,i,o=255;if(e){if(e[7]!==n){const t=+e[7];o=e[8]?Et(t):_t(255*t,0,255)}return n=+e[1],r=+e[3],i=+e[5],n=255&(e[2]?Et(n):_t(n,0,255)),r=255&(e[4]?Et(r):_t(r,0,255)),i=255&(e[6]?Et(i):_t(i,0,255)),{r:n,g:r,b:i,a:o}}}(t):Wt(t)}class te{constructor(t){if(t instanceof te)return t;const e=typeof t;let n;"object"===e?n=Zt(t):"string"===e&&(n=function(t){var e,n=t.length;return"#"===t[0]&&(4===n||5===n?e={r:255&17*Rt[t[1]],g:255&17*Rt[t[2]],b:255&17*Rt[t[3]],a:5===n?17*Rt[t[4]]:255}:7!==n&&9!==n||(e={r:Rt[t[1]]<<4|Rt[t[2]],g:Rt[t[3]]<<4|Rt[t[4]],b:Rt[t[5]]<<4|Rt[t[6]],a:9===n?Rt[t[7]]<<4|Rt[t[8]]:255})),e}(t)||Ht(t)||Qt(t)),this._rgb=n,this._valid=!!n}get valid(){return this._valid}get rgb(){var t=Kt(this._rgb);return t&&(t.a=St(t.a)),t}set rgb(t){this._rgb=Zt(t)}rgbString(){return this._valid?(t=this._rgb)&&(t.a<255?`rgba(${t.r}, ${t.g}, ${t.b}, ${St(t.a)})`:`rgb(${t.r}, ${t.g}, ${t.b})`):void 0;var t}hexString(){return this._valid?It(this._rgb):void 0}hslString(){return this._valid?function(t){if(!t)return;const e=Bt(t),n=e[0],r=Ct(e[1]),i=Ct(e[2]);return t.a<255?`hsla(${n}, ${r}%, ${i}%, ${St(t.a)})`:`hsl(${n}, ${r}%, ${i}%)`}(this._rgb):void 0}mix(t,e){if(t){const n=this.rgb,r=t.rgb;let i;const o=e===i?.5:e,a=2*o-1,s=n.a-r.a,c=((a*s===-1?a:(a+s)/(1+a*s))+1)/2;i=1-c,n.r=255&c*n.r+i*r.r+.5,n.g=255&c*n.g+i*r.g+.5,n.b=255&c*n.b+i*r.b+.5,n.a=o*n.a+(1-o)*r.a,this.rgb=n}return this}interpolate(t,e){return t&&(this._rgb=function(t,e,n){const r=Ut(St(t.r)),i=Ut(St(t.g)),o=Ut(St(t.b));return{r:Ot(qt(r+n*(Ut(St(e.r))-r))),g:Ot(qt(i+n*(Ut(St(e.g))-i))),b:Ot(qt(o+n*(Ut(St(e.b))-o))),a:t.a+n*(e.a-t.a)}}(this._rgb,t._rgb,e)),this}clone(){return new te(this.rgb)}alpha(t){return this._rgb.a=Ot(t),this}clearer(t){return this._rgb.a*=1-t,this}greyscale(){const t=this._rgb,e=kt(.3*t.r+.59*t.g+.11*t.b);return t.r=t.g=t.b=e,this}opaquer(t){return this._rgb.a*=1+t,this}negate(){const t=this._rgb;return t.r=255-t.r,t.g=255-t.g,t.b=255-t.b,this}lighten(t){return Jt(this._rgb,2,t),this}darken(t){return Jt(this._rgb,2,-t),this}saturate(t){return Jt(this._rgb,1,t),this}desaturate(t){return Jt(this._rgb,1,-t),this}rotate(t){return function(t,e){var n=Bt(t);n[0]=Yt(n[0]+e),n=$t(n),t.r=n[0],t.g=n[1],t.b=n[2]}(this._rgb,t),this}}function ee(t){return new te(t)}function ne(t){if(t&&"object"===typeof t){const e=t.toString();return"[object CanvasPattern]"===e||"[object CanvasGradient]"===e}return!1}function re(t){return ne(t)?t:ee(t)}function ie(t){return ne(t)?t:ee(t).saturate(.5).darken(.1).hexString()}const oe=Object.create(null),ae=Object.create(null);function se(t,e){if(!e)return t;const n=e.split(".");for(let r=0,i=n.length;r<i;++r){const e=n[r];t=t[e]||(t[e]=Object.create(null))}return t}function ce(t,e,n){return"string"===typeof e?x(se(t,e),n):x(se(t,""),e)}var le=new class{constructor(t){this.animation=void 0,this.backgroundColor="rgba(0,0,0,0.1)",this.borderColor="rgba(0,0,0,0.1)",this.color="#666",this.datasets={},this.devicePixelRatio=t=>t.chart.platform.getDevicePixelRatio(),this.elements={},this.events=["mousemove","mouseout","click","touchstart","touchmove"],this.font={family:"'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",size:12,style:"normal",lineHeight:1.2,weight:null},this.hover={},this.hoverBackgroundColor=(t,e)=>ie(e.backgroundColor),this.hoverBorderColor=(t,e)=>ie(e.borderColor),this.hoverColor=(t,e)=>ie(e.color),this.indexAxis="x",this.interaction={mode:"nearest",intersect:!0,includeInvisible:!1},this.maintainAspectRatio=!0,this.onHover=null,this.onClick=null,this.parsing=!0,this.plugins={},this.responsive=!0,this.scale=void 0,this.scales={},this.showLine=!0,this.drawActiveElementsOnTop=!0,this.describe(t)}set(t,e){return ce(this,t,e)}get(t){return se(this,t)}describe(t,e){return ce(ae,t,e)}override(t,e){return ce(oe,t,e)}route(t,e,n,r){const i=se(this,t),o=se(this,n),a="_"+e;Object.defineProperties(i,{[a]:{value:i[e],writable:!0},[e]:{enumerable:!0,get(){const t=this[a],e=o[r];return s(t)?Object.assign({},e,t):u(t,e)},set(t){this[a]=t}}})}}({_scriptable:t=>!t.startsWith("on"),_indexable:t=>"events"!==t,hover:{_fallback:"interaction"},interaction:{_scriptable:!1,_indexable:!1}});function ue(t,e,n,r,i){let o=e[i];return o||(o=e[i]=t.measureText(i).width,n.push(i)),o>r&&(r=o),r}function fe(t,e,n,r){let i=(r=r||{}).data=r.data||{},o=r.garbageCollect=r.garbageCollect||[];r.font!==e&&(i=r.data={},o=r.garbageCollect=[],r.font=e),t.save(),t.font=e;let s=0;const c=n.length;let l,u,f,d,p;for(l=0;l<c;l++)if(d=n[l],void 0!==d&&null!==d&&!0!==a(d))s=ue(t,i,o,s,d);else if(a(d))for(u=0,f=d.length;u<f;u++)p=d[u],void 0===p||null===p||a(p)||(s=ue(t,i,o,s,p));t.restore();const h=o.length/2;if(h>n.length){for(l=0;l<h;l++)delete i[o[l]];o.splice(0,h)}return s}function de(t,e,n){const r=t.currentDevicePixelRatio,i=0!==n?Math.max(n/2,.5):0;return Math.round((e-i)*r)/r+i}function pe(t,e){(e=e||t.getContext("2d")).save(),e.resetTransform(),e.clearRect(0,0,t.width,t.height),e.restore()}function he(t,e,n,r){me(t,e,n,r,null)}function me(t,e,n,r,i){let o,a,s,c,l,u;const f=e.pointStyle,d=e.rotation,p=e.radius;let h=(d||0)*I;if(f&&"object"===typeof f&&(o=f.toString(),"[object HTMLImageElement]"===o||"[object HTMLCanvasElement]"===o))return t.save(),t.translate(n,r),t.rotate(h),t.drawImage(f,-f.width/2,-f.height/2,f.width,f.height),void t.restore();if(!(isNaN(p)||p<=0)){switch(t.beginPath(),f){default:i?t.ellipse(n,r,i/2,p,0,0,M):t.arc(n,r,p,0,M),t.closePath();break;case"triangle":t.moveTo(n+Math.sin(h)*p,r-Math.cos(h)*p),h+=D,t.lineTo(n+Math.sin(h)*p,r-Math.cos(h)*p),h+=D,t.lineTo(n+Math.sin(h)*p,r-Math.cos(h)*p),t.closePath();break;case"rectRounded":l=.516*p,c=p-l,a=Math.cos(h+j)*c,s=Math.sin(h+j)*c,t.arc(n-a,r-s,l,h-T,h-P),t.arc(n+s,r-a,l,h-P,h),t.arc(n+a,r+s,l,h,h+P),t.arc(n-s,r+a,l,h+P,h+T),t.closePath();break;case"rect":if(!d){c=Math.SQRT1_2*p,u=i?i/2:c,t.rect(n-u,r-c,2*u,2*c);break}h+=j;case"rectRot":a=Math.cos(h)*p,s=Math.sin(h)*p,t.moveTo(n-a,r-s),t.lineTo(n+s,r-a),t.lineTo(n+a,r+s),t.lineTo(n-s,r+a),t.closePath();break;case"crossRot":h+=j;case"cross":a=Math.cos(h)*p,s=Math.sin(h)*p,t.moveTo(n-a,r-s),t.lineTo(n+a,r+s),t.moveTo(n+s,r-a),t.lineTo(n-s,r+a);break;case"star":a=Math.cos(h)*p,s=Math.sin(h)*p,t.moveTo(n-a,r-s),t.lineTo(n+a,r+s),t.moveTo(n+s,r-a),t.lineTo(n-s,r+a),h+=j,a=Math.cos(h)*p,s=Math.sin(h)*p,t.moveTo(n-a,r-s),t.lineTo(n+a,r+s),t.moveTo(n+s,r-a),t.lineTo(n-s,r+a);break;case"line":a=i?i/2:Math.cos(h)*p,s=Math.sin(h)*p,t.moveTo(n-a,r-s),t.lineTo(n+a,r+s);break;case"dash":t.moveTo(n,r),t.lineTo(n+Math.cos(h)*p,r+Math.sin(h)*p)}t.fill(),e.borderWidth>0&&t.stroke()}}function ye(t,e,n){return n=n||.5,!e||t&&t.x>e.left-n&&t.x<e.right+n&&t.y>e.top-n&&t.y<e.bottom+n}function ge(t,e){t.save(),t.beginPath(),t.rect(e.left,e.top,e.right-e.left,e.bottom-e.top),t.clip()}function be(t){t.restore()}function xe(t,e,n,r,i){if(!e)return t.lineTo(n.x,n.y);if("middle"===i){const r=(e.x+n.x)/2;t.lineTo(r,e.y),t.lineTo(r,n.y)}else"after"===i!==!!r?t.lineTo(e.x,n.y):t.lineTo(n.x,e.y);t.lineTo(n.x,n.y)}function ve(t,e,n,r){if(!e)return t.lineTo(n.x,n.y);t.bezierCurveTo(r?e.cp1x:e.cp2x,r?e.cp1y:e.cp2y,r?n.cp2x:n.cp1x,r?n.cp2y:n.cp1y,n.x,n.y)}function we(t,e,n,r,i,s={}){const c=a(e)?e:[e],l=s.strokeWidth>0&&""!==s.strokeColor;let u,f;for(t.save(),t.font=i.string,function(t,e){e.translation&&t.translate(e.translation[0],e.translation[1]);o(e.rotation)||t.rotate(e.rotation);e.color&&(t.fillStyle=e.color);e.textAlign&&(t.textAlign=e.textAlign);e.textBaseline&&(t.textBaseline=e.textBaseline)}(t,s),u=0;u<c.length;++u)f=c[u],l&&(s.strokeColor&&(t.strokeStyle=s.strokeColor),o(s.strokeWidth)||(t.lineWidth=s.strokeWidth),t.strokeText(f,n,r,s.maxWidth)),t.fillText(f,n,r,s.maxWidth),ke(t,n,r,f,s),r+=i.lineHeight;t.restore()}function ke(t,e,n,r,i){if(i.strikethrough||i.underline){const o=t.measureText(r),a=e-o.actualBoundingBoxLeft,s=e+o.actualBoundingBoxRight,c=n-o.actualBoundingBoxAscent,l=n+o.actualBoundingBoxDescent,u=i.strikethrough?(c+l)/2:l;t.strokeStyle=t.fillStyle,t.beginPath(),t.lineWidth=i.decorationWidth||2,t.moveTo(a,u),t.lineTo(s,u),t.stroke()}}function _e(t,e){const{x:n,y:r,w:i,h:o,radius:a}=e;t.arc(n+a.topLeft,r+a.topLeft,a.topLeft,-P,T,!0),t.lineTo(n,r+o-a.bottomLeft),t.arc(n+a.bottomLeft,r+o-a.bottomLeft,a.bottomLeft,T,P,!0),t.lineTo(n+i-a.bottomRight,r+o),t.arc(n+i-a.bottomRight,r+o-a.bottomRight,a.bottomRight,P,0,!0),t.lineTo(n+i,r+a.topRight),t.arc(n+i-a.topRight,r+a.topRight,a.topRight,0,-P,!0),t.lineTo(n+a.topLeft,r)}const Ee=new RegExp(/^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/),Oe=new RegExp(/^(normal|italic|initial|inherit|unset|(oblique( -?[0-9]?[0-9]deg)?))$/);function Se(t,e){const n=(""+t).match(Ee);if(!n||"normal"===n[1])return 1.2*e;switch(t=+n[2],n[3]){case"px":return t;case"%":t/=100}return e*t}function Ce(t,e){const n={},r=s(e),i=r?Object.keys(e):e,o=s(t)?r?n=>u(t[n],t[e[n]]):e=>t[e]:()=>t;for(const a of i)n[a]=+o(a)||0;return n}function Re(t){return Ce(t,{top:"y",right:"x",bottom:"y",left:"x"})}function Te(t){return Ce(t,["topLeft","topRight","bottomLeft","bottomRight"])}function Me(t){const e=Re(t);return e.width=e.left+e.right,e.height=e.top+e.bottom,e}function Fe(t,e){t=t||{},e=e||le.font;let n=u(t.size,e.size);"string"===typeof n&&(n=parseInt(n,10));let r=u(t.style,e.style);r&&!(""+r).match(Oe)&&(console.warn('Invalid font style specified: "'+r+'"'),r="");const i={family:u(t.family,e.family),lineHeight:Se(u(t.lineHeight,e.lineHeight),n),size:n,style:r,weight:u(t.weight,e.weight),string:""};return i.string=function(t){return!t||o(t.size)||o(t.family)?null:(t.style?t.style+" ":"")+(t.weight?t.weight+" ":"")+t.size+"px "+t.family}(i),i}function Ne(t,e,n,r){let i,o,s,c=!0;for(i=0,o=t.length;i<o;++i)if(s=t[i],void 0!==s&&(void 0!==e&&"function"===typeof s&&(s=s(e),c=!1),void 0!==n&&a(s)&&(s=s[n%s.length],c=!1),void 0!==s))return r&&!c&&(r.cacheable=!1),s}function Ie(t,e,n){const{min:r,max:i}=t,o=d(e,(i-r)/2),a=(t,e)=>n&&0===t?0:t+e;return{min:a(r,-Math.abs(o)),max:a(i,o)}}function Pe(t,e){return Object.assign(Object.create(t),e)}function je(t,e=[""],n=t,r,i=(()=>t[0])){O(r)||(r=He("_fallback",t));const o={[Symbol.toStringTag]:"Object",_cacheable:!0,_scopes:t,_rootScopes:n,_fallback:r,_getTarget:i,override:i=>je([i,...t],e,n,r)};return new Proxy(o,{deleteProperty:(e,n)=>(delete e[n],delete e._keys,delete t[0][n],!0),get:(n,r)=>$e(n,r,(()=>function(t,e,n,r){let i;for(const o of e)if(i=He(Be(o,t),n),O(i))return Le(t,i)?Ve(n,r,t,i):i}(r,e,t,n))),getOwnPropertyDescriptor:(t,e)=>Reflect.getOwnPropertyDescriptor(t._scopes[0],e),getPrototypeOf:()=>Reflect.getPrototypeOf(t[0]),has:(t,e)=>Ge(t).includes(e),ownKeys:t=>Ge(t),set(t,e,n){const r=t._storage||(t._storage=i());return t[e]=r[e]=n,delete t._keys,!0}})}function De(t,e,n,r){const i={_cacheable:!1,_proxy:t,_context:e,_subProxy:n,_stack:new Set,_descriptors:Ae(t,r),setContext:e=>De(t,e,n,r),override:i=>De(t.override(i),e,n,r)};return new Proxy(i,{deleteProperty:(e,n)=>(delete e[n],delete t[n],!0),get:(t,e,n)=>$e(t,e,(()=>function(t,e,n){const{_proxy:r,_context:i,_subProxy:o,_descriptors:c}=t;let l=r[e];S(l)&&c.isScriptable(e)&&(l=function(t,e,n,r){const{_proxy:i,_context:o,_subProxy:a,_stack:s}=n;if(s.has(t))throw new Error("Recursion detected: "+Array.from(s).join("->")+"->"+t);s.add(t),e=e(o,a||r),s.delete(t),Le(t,e)&&(e=Ve(i._scopes,i,t,e));return e}(e,l,t,n));a(l)&&l.length&&(l=function(t,e,n,r){const{_proxy:i,_context:o,_subProxy:a,_descriptors:c}=n;if(O(o.index)&&r(t))e=e[o.index%e.length];else if(s(e[0])){const n=e,r=i._scopes.filter((t=>t!==n));e=[];for(const s of n){const n=Ve(r,i,t,s);e.push(De(n,o,a&&a[t],c))}}return e}(e,l,t,c.isIndexable));Le(e,l)&&(l=De(l,i,o&&o[e],c));return l}(t,e,n))),getOwnPropertyDescriptor:(e,n)=>e._descriptors.allKeys?Reflect.has(t,n)?{enumerable:!0,configurable:!0}:void 0:Reflect.getOwnPropertyDescriptor(t,n),getPrototypeOf:()=>Reflect.getPrototypeOf(t),has:(e,n)=>Reflect.has(t,n),ownKeys:()=>Reflect.ownKeys(t),set:(e,n,r)=>(t[n]=r,delete e[n],!0)})}function Ae(t,e={scriptable:!0,indexable:!0}){const{_scriptable:n=e.scriptable,_indexable:r=e.indexable,_allKeys:i=e.allKeys}=t;return{allKeys:i,scriptable:n,indexable:r,isScriptable:S(n)?n:()=>n,isIndexable:S(r)?r:()=>r}}const Be=(t,e)=>t?t+E(e):e,Le=(t,e)=>s(e)&&"adapters"!==t&&(null===Object.getPrototypeOf(e)||e.constructor===Object);function $e(t,e,n){if(Object.prototype.hasOwnProperty.call(t,e))return t[e];const r=n();return t[e]=r,r}function Ye(t,e,n){return S(t)?t(e,n):t}const We=(t,e)=>!0===t?e:"string"===typeof t?_(e,t):void 0;function ze(t,e,n,r,i){for(const o of e){const e=We(n,o);if(e){t.add(e);const o=Ye(e._fallback,n,i);if(O(o)&&o!==n&&o!==r)return o}else if(!1===e&&O(r)&&n!==r)return null}return!1}function Ve(t,e,n,r){const i=e._rootScopes,o=Ye(e._fallback,n,r),c=[...t,...i],l=new Set;l.add(r);let u=Xe(l,c,n,o||n,r);return null!==u&&((!O(o)||o===n||(u=Xe(l,c,o,u,r),null!==u))&&je(Array.from(l),[""],i,o,(()=>function(t,e,n){const r=t._getTarget();e in r||(r[e]={});const i=r[e];if(a(i)&&s(n))return n;return i}(e,n,r))))}function Xe(t,e,n,r,i){for(;n;)n=ze(t,e,n,r,i);return n}function He(t,e){for(const n of e){if(!n)continue;const e=n[t];if(O(e))return e}}function Ge(t){let e=t._keys;return e||(e=t._keys=function(t){const e=new Set;for(const n of t)for(const t of Object.keys(n).filter((t=>!t.startsWith("_"))))e.add(t);return Array.from(e)}(t._scopes)),e}function qe(t,e,n,r){const{iScale:i}=t,{key:o="r"}=this._parsing,a=new Array(r);let s,c,l,u;for(s=0,c=r;s<c;++s)l=s+n,u=e[l],a[s]={r:i.parse(_(u,o),l)};return a}const Ue=Number.EPSILON||1e-14,Je=(t,e)=>e<t.length&&!t[e].skip&&t[e],Ke=t=>"x"===t?"y":"x";function Ze(t,e,n,r){const i=t.skip?e:t,o=e,a=n.skip?e:n,s=U(o,i),c=U(a,o);let l=s/(s+c),u=c/(s+c);l=isNaN(l)?0:l,u=isNaN(u)?0:u;const f=r*l,d=r*u;return{previous:{x:o.x-f*(a.x-i.x),y:o.y-f*(a.y-i.y)},next:{x:o.x+d*(a.x-i.x),y:o.y+d*(a.y-i.y)}}}function Qe(t,e="x"){const n=Ke(e),r=t.length,i=Array(r).fill(0),o=Array(r);let a,s,c,l=Je(t,0);for(a=0;a<r;++a)if(s=c,c=l,l=Je(t,a+1),c){if(l){const t=l[e]-c[e];i[a]=0!==t?(l[n]-c[n])/t:0}o[a]=s?l?B(i[a-1])!==B(i[a])?0:(i[a-1]+i[a])/2:i[a-1]:i[a]}!function(t,e,n){const r=t.length;let i,o,a,s,c,l=Je(t,0);for(let u=0;u<r-1;++u)c=l,l=Je(t,u+1),c&&l&&(W(e[u],0,Ue)?n[u]=n[u+1]=0:(i=n[u]/e[u],o=n[u+1]/e[u],s=Math.pow(i,2)+Math.pow(o,2),s<=9||(a=3/Math.sqrt(s),n[u]=i*a*e[u],n[u+1]=o*a*e[u])))}(t,i,o),function(t,e,n="x"){const r=Ke(n),i=t.length;let o,a,s,c=Je(t,0);for(let l=0;l<i;++l){if(a=s,s=c,c=Je(t,l+1),!s)continue;const i=s[n],u=s[r];a&&(o=(i-a[n])/3,s[`cp1${n}`]=i-o,s[`cp1${r}`]=u-o*e[l]),c&&(o=(c[n]-i)/3,s[`cp2${n}`]=i+o,s[`cp2${r}`]=u+o*e[l])}}(t,o,e)}function tn(t,e,n){return Math.max(Math.min(t,n),e)}function en(t,e,n,r,i){let o,a,s,c;if(e.spanGaps&&(t=t.filter((t=>!t.skip))),"monotone"===e.cubicInterpolationMode)Qe(t,i);else{let n=r?t[t.length-1]:t[0];for(o=0,a=t.length;o<a;++o)s=t[o],c=Ze(n,s,t[Math.min(o+1,a-(r?0:1))%a],e.tension),s.cp1x=c.previous.x,s.cp1y=c.previous.y,s.cp2x=c.next.x,s.cp2y=c.next.y,n=s}e.capBezierPoints&&function(t,e){let n,r,i,o,a,s=ye(t[0],e);for(n=0,r=t.length;n<r;++n)a=o,o=s,s=n<r-1&&ye(t[n+1],e),o&&(i=t[n],a&&(i.cp1x=tn(i.cp1x,e.left,e.right),i.cp1y=tn(i.cp1y,e.top,e.bottom)),s&&(i.cp2x=tn(i.cp2x,e.left,e.right),i.cp2y=tn(i.cp2y,e.top,e.bottom)))}(t,n)}function nn(){return"undefined"!==typeof window&&"undefined"!==typeof document}function rn(t){let e=t.parentNode;return e&&"[object ShadowRoot]"===e.toString()&&(e=e.host),e}function on(t,e,n){let r;return"string"===typeof t?(r=parseInt(t,10),-1!==t.indexOf("%")&&(r=r/100*e.parentNode[n])):r=t,r}const an=t=>window.getComputedStyle(t,null);const sn=["top","right","bottom","left"];function cn(t,e,n){const r={};n=n?"-"+n:"";for(let i=0;i<4;i++){const o=sn[i];r[o]=parseFloat(t[e+"-"+o+n])||0}return r.width=r.left+r.right,r.height=r.top+r.bottom,r}function ln(t,e){if("native"in t)return t;const{canvas:n,currentDevicePixelRatio:r}=e,i=an(n),o="border-box"===i.boxSizing,a=cn(i,"padding"),s=cn(i,"border","width"),{x:c,y:l,box:u}=function(t,e){const n=t.touches,r=n&&n.length?n[0]:t,{offsetX:i,offsetY:o}=r;let a,s,c=!1;if(((t,e,n)=>(t>0||e>0)&&(!n||!n.shadowRoot))(i,o,t.target))a=i,s=o;else{const t=e.getBoundingClientRect();a=r.clientX-t.left,s=r.clientY-t.top,c=!0}return{x:a,y:s,box:c}}(t,n),f=a.left+(u&&s.left),d=a.top+(u&&s.top);let{width:p,height:h}=e;return o&&(p-=a.width+s.width,h-=a.height+s.height),{x:Math.round((c-f)/p*n.width/r),y:Math.round((l-d)/h*n.height/r)}}const un=t=>Math.round(10*t)/10;function fn(t,e,n,r){const i=an(t),o=cn(i,"margin"),a=on(i.maxWidth,t,"clientWidth")||N,s=on(i.maxHeight,t,"clientHeight")||N,c=function(t,e,n){let r,i;if(void 0===e||void 0===n){const o=rn(t);if(o){const t=o.getBoundingClientRect(),a=an(o),s=cn(a,"border","width"),c=cn(a,"padding");e=t.width-c.width-s.width,n=t.height-c.height-s.height,r=on(a.maxWidth,o,"clientWidth"),i=on(a.maxHeight,o,"clientHeight")}else e=t.clientWidth,n=t.clientHeight}return{width:e,height:n,maxWidth:r||N,maxHeight:i||N}}(t,e,n);let{width:l,height:u}=c;if("content-box"===i.boxSizing){const t=cn(i,"border","width"),e=cn(i,"padding");l-=e.width+t.width,u-=e.height+t.height}return l=Math.max(0,l-o.width),u=Math.max(0,r?Math.floor(l/r):u-o.height),l=un(Math.min(l,a,c.maxWidth)),u=un(Math.min(u,s,c.maxHeight)),l&&!u&&(u=un(l/2)),{width:l,height:u}}function dn(t,e,n){const r=e||1,i=Math.floor(t.height*r),o=Math.floor(t.width*r);t.height=i/r,t.width=o/r;const a=t.canvas;return a.style&&(n||!a.style.height&&!a.style.width)&&(a.style.height=`${t.height}px`,a.style.width=`${t.width}px`),(t.currentDevicePixelRatio!==r||a.height!==i||a.width!==o)&&(t.currentDevicePixelRatio=r,a.height=i,a.width=o,t.ctx.setTransform(r,0,0,r,0,0),!0)}const pn=function(){let t=!1;try{const e={get passive(){return t=!0,!1}};window.addEventListener("test",null,e),window.removeEventListener("test",null,e)}catch(e){}return t}();function hn(t,e){const n=function(t,e){return an(t).getPropertyValue(e)}(t,e),r=n&&n.match(/^(\d+)(\.\d+)?px$/);return r?+r[1]:void 0}function mn(t,e,n,r){return{x:t.x+n*(e.x-t.x),y:t.y+n*(e.y-t.y)}}function yn(t,e,n,r){return{x:t.x+n*(e.x-t.x),y:"middle"===r?n<.5?t.y:e.y:"after"===r?n<1?t.y:e.y:n>0?e.y:t.y}}function gn(t,e,n,r){const i={x:t.cp2x,y:t.cp2y},o={x:e.cp1x,y:e.cp1y},a=mn(t,i,n),s=mn(i,o,n),c=mn(o,e,n),l=mn(a,s,n),u=mn(s,c,n);return mn(l,u,n)}const bn=new Map;function xn(t,e,n){return function(t,e){e=e||{};const n=t+JSON.stringify(e);let r=bn.get(n);return r||(r=new Intl.NumberFormat(t,e),bn.set(n,r)),r}(e,n).format(t)}function vn(t,e,n){return t?function(t,e){return{x:n=>t+t+e-n,setWidth(t){e=t},textAlign:t=>"center"===t?t:"right"===t?"left":"right",xPlus:(t,e)=>t-e,leftForLtr:(t,e)=>t-e}}(e,n):{x:t=>t,setWidth(t){},textAlign:t=>t,xPlus:(t,e)=>t+e,leftForLtr:(t,e)=>t}}function wn(t,e){let n,r;"ltr"!==e&&"rtl"!==e||(n=t.canvas.style,r=[n.getPropertyValue("direction"),n.getPropertyPriority("direction")],n.setProperty("direction",e,"important"),t.prevTextDirection=r)}function kn(t,e){void 0!==e&&(delete t.prevTextDirection,t.canvas.style.setProperty("direction",e[0],e[1]))}function _n(t){return"angle"===t?{between:Z,compare:J,normalize:K}:{between:et,compare:(t,e)=>t-e,normalize:t=>t}}function En({start:t,end:e,count:n,loop:r,style:i}){return{start:t%n,end:e%n,loop:r&&(e-t+1)%n===0,style:i}}function On(t,e,n){if(!n)return[t];const{property:r,start:i,end:o}=n,a=e.length,{compare:s,between:c,normalize:l}=_n(r),{start:u,end:f,loop:d,style:p}=function(t,e,n){const{property:r,start:i,end:o}=n,{between:a,normalize:s}=_n(r),c=e.length;let l,u,{start:f,end:d,loop:p}=t;if(p){for(f+=c,d+=c,l=0,u=c;l<u&&a(s(e[f%c][r]),i,o);++l)f--,d--;f%=c,d%=c}return d<f&&(d+=c),{start:f,end:d,loop:p,style:t.style}}(t,e,n),h=[];let m,y,g,b=!1,x=null;const v=()=>b||c(i,g,m)&&0!==s(i,g),w=()=>!b||0===s(o,m)||c(o,g,m);for(let k=u,_=u;k<=f;++k)y=e[k%a],y.skip||(m=l(y[r]),m!==g&&(b=c(m,i,o),null===x&&v()&&(x=0===s(m,i)?k:_),null!==x&&w()&&(h.push(En({start:x,end:k,loop:d,count:a,style:p})),x=null),_=k,g=m));return null!==x&&h.push(En({start:x,end:f,loop:d,count:a,style:p})),h}function Sn(t,e){const n=[],r=t.segments;for(let i=0;i<r.length;i++){const o=On(r[i],t.points,e);o.length&&n.push(...o)}return n}function Cn(t,e){const n=t.points,r=t.options.spanGaps,i=n.length;if(!i)return[];const o=!!t._loop,{start:a,end:s}=function(t,e,n,r){let i=0,o=e-1;if(n&&!r)for(;i<e&&!t[i].skip;)i++;for(;i<e&&t[i].skip;)i++;for(i%=e,n&&(o+=i);o>i&&t[o%e].skip;)o--;return o%=e,{start:i,end:o}}(n,i,o,r);if(!0===r)return Rn(t,[{start:a,end:s,loop:o}],n,e);return Rn(t,function(t,e,n,r){const i=t.length,o=[];let a,s=e,c=t[e];for(a=e+1;a<=n;++a){const n=t[a%i];n.skip||n.stop?c.skip||(r=!1,o.push({start:e%i,end:(a-1)%i,loop:r}),e=s=n.stop?a:null):(s=a,c.skip&&(e=a)),c=n}return null!==s&&o.push({start:e%i,end:s%i,loop:r}),o}(n,a,s<a?s+i:s,!!t._fullLoop&&0===a&&s===i-1),n,e)}function Rn(t,e,n,r){return r&&r.setContext&&n?function(t,e,n,r){const i=t._chart.getContext(),o=Tn(t.options),{_datasetIndex:a,options:{spanGaps:s}}=t,c=n.length,l=[];let u=o,f=e[0].start,d=f;function p(t,e,r,i){const o=s?-1:1;if(t!==e){for(t+=c;n[t%c].skip;)t-=o;for(;n[e%c].skip;)e+=o;t%c!==e%c&&(l.push({start:t%c,end:e%c,loop:r,style:i}),u=i,f=e%c)}}for(const h of e){f=s?f:h.start;let t,e=n[f%c];for(d=f+1;d<=h.end;d++){const o=n[d%c];t=Tn(r.setContext(Pe(i,{type:"segment",p0:e,p1:o,p0DataIndex:(d-1)%c,p1DataIndex:d%c,datasetIndex:a}))),Mn(t,u)&&p(f,d-1,h.loop,u),e=o,u=t}f<d-1&&p(f,d-1,h.loop,u)}return l}(t,e,n,r):e}function Tn(t){return{backgroundColor:t.backgroundColor,borderCapStyle:t.borderCapStyle,borderDash:t.borderDash,borderDashOffset:t.borderDashOffset,borderJoinStyle:t.borderJoinStyle,borderWidth:t.borderWidth,borderColor:t.borderColor}}function Mn(t,e){return e&&JSON.stringify(t)!==JSON.stringify(e)}},826:function(t,e,n){"use strict";n.d(e,{sm:function(){return U},pT:function(){return lt}});var r=n(7294),i=n(917);function o(){return o=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},o.apply(this,arguments)}const a=new Map,s=new WeakMap;let c,l=0;function u(t){return Object.keys(t).sort().filter((e=>void 0!==t[e])).map((e=>{return`${e}_${"root"===e?(n=t.root,n?(s.has(n)||(l+=1,s.set(n,l.toString())),s.get(n)):"0"):t[e]}`;var n})).toString()}function f(t,e,n={},r=c){if("undefined"===typeof window.IntersectionObserver&&void 0!==r){const i=t.getBoundingClientRect();return e(r,{isIntersecting:r,target:t,intersectionRatio:"number"===typeof n.threshold?n.threshold:0,time:0,boundingClientRect:i,intersectionRect:i,rootBounds:i}),()=>{}}const{id:i,observer:o,elements:s}=function(t){let e=u(t),n=a.get(e);if(!n){const r=new Map;let i;const o=new IntersectionObserver((e=>{e.forEach((e=>{var n;const o=e.isIntersecting&&i.some((t=>e.intersectionRatio>=t));t.trackVisibility&&"undefined"===typeof e.isVisible&&(e.isVisible=o),null==(n=r.get(e.target))||n.forEach((t=>{t(o,e)}))}))}),t);i=o.thresholds||(Array.isArray(t.threshold)?t.threshold:[t.threshold||0]),n={id:e,observer:o,elements:r},a.set(e,n)}return n}(n);let l=s.get(t)||[];return s.has(t)||s.set(t,l),l.push(e),o.observe(t),function(){l.splice(l.indexOf(e),1),0===l.length&&(s.delete(t),o.unobserve(t)),0===s.size&&(o.disconnect(),a.delete(i))}}const d=["children","as","triggerOnce","threshold","root","rootMargin","onChange","skip","trackVisibility","delay","initialInView","fallbackInView"];function p(t){return"function"!==typeof t.children}class h extends r.Component{constructor(t){super(t),this.node=null,this._unobserveCb=null,this.handleNode=t=>{this.node&&(this.unobserve(),t||this.props.triggerOnce||this.props.skip||this.setState({inView:!!this.props.initialInView,entry:void 0})),this.node=t||null,this.observeNode()},this.handleChange=(t,e)=>{t&&this.props.triggerOnce&&this.unobserve(),p(this.props)||this.setState({inView:t,entry:e}),this.props.onChange&&this.props.onChange(t,e)},this.state={inView:!!t.initialInView,entry:void 0}}componentDidUpdate(t){t.rootMargin===this.props.rootMargin&&t.root===this.props.root&&t.threshold===this.props.threshold&&t.skip===this.props.skip&&t.trackVisibility===this.props.trackVisibility&&t.delay===this.props.delay||(this.unobserve(),this.observeNode())}componentWillUnmount(){this.unobserve(),this.node=null}observeNode(){if(!this.node||this.props.skip)return;const{threshold:t,root:e,rootMargin:n,trackVisibility:r,delay:i,fallbackInView:o}=this.props;this._unobserveCb=f(this.node,this.handleChange,{threshold:t,root:e,rootMargin:n,trackVisibility:r,delay:i},o)}unobserve(){this._unobserveCb&&(this._unobserveCb(),this._unobserveCb=null)}render(){if(!p(this.props)){const{inView:t,entry:e}=this.state;return this.props.children({inView:t,entry:e,ref:this.handleNode})}const t=this.props,{children:e,as:n}=t,i=function(t,e){if(null==t)return{};var n,r,i={},o=Object.keys(t);for(r=0;r<o.length;r++)n=o[r],e.indexOf(n)>=0||(i[n]=t[n]);return i}(t,d);return r.createElement(n||"div",o({ref:this.handleNode},i),e)}}function m({threshold:t,delay:e,trackVisibility:n,rootMargin:i,root:o,triggerOnce:a,skip:s,initialInView:c,fallbackInView:l,onChange:u}={}){var d;const[p,h]=r.useState(null),m=r.useRef(),[y,g]=r.useState({inView:!!c,entry:void 0});m.current=u,r.useEffect((()=>{if(s||!p)return;let r=f(p,((t,e)=>{g({inView:t,entry:e}),m.current&&m.current(t,e),e.isIntersecting&&a&&r&&(r(),r=void 0)}),{root:o,rootMargin:i,threshold:t,trackVisibility:n,delay:e},l);return()=>{r&&r()}}),[Array.isArray(t)?t.toString():t,p,o,i,a,s,n,l,e]);const b=null==(d=y.entry)?void 0:d.target;r.useEffect((()=>{p||!b||a||s||g({inView:!!c,entry:void 0})}),[p,b,a,s,c]);const x=[h,y.inView,y.entry];return x.ref=x[0],x.inView=x[1],x.entry=x[2],x}var y=n(4954),g=(n(8357),n(1683)),b=(n(8679),n(8137),n(7278),n(5893)),x=b.Fragment;function v(t,e,n){return g.h.call(e,"css")?(0,b.jsx)(g.E,(0,g.c)(t,e),n):(0,b.jsx)(t,e,n)}i.F4`
  from,
  20%,
  53%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
    transform: translate3d(0, 0, 0);
  }

  40%,
  43% {
    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
    transform: translate3d(0, -30px, 0) scaleY(1.1);
  }

  70% {
    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
    transform: translate3d(0, -15px, 0) scaleY(1.05);
  }

  80% {
    transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
    transform: translate3d(0, 0, 0) scaleY(0.95);
  }

  90% {
    transform: translate3d(0, -4px, 0) scaleY(1.02);
  }
`,i.F4`
  from,
  50%,
  to {
    opacity: 1;
  }

  25%,
  75% {
    opacity: 0;
  }
`,i.F4`
  0% {
    transform: translateX(0);
  }

  6.5% {
    transform: translateX(-6px) rotateY(-9deg);
  }

  18.5% {
    transform: translateX(5px) rotateY(7deg);
  }

  31.5% {
    transform: translateX(-3px) rotateY(-5deg);
  }

  43.5% {
    transform: translateX(2px) rotateY(3deg);
  }

  50% {
    transform: translateX(0);
  }
`,i.F4`
  0% {
    transform: scale(1);
  }

  14% {
    transform: scale(1.3);
  }

  28% {
    transform: scale(1);
  }

  42% {
    transform: scale(1.3);
  }

  70% {
    transform: scale(1);
  }
`,i.F4`
  from,
  11.1%,
  to {
    transform: translate3d(0, 0, 0);
  }

  22.2% {
    transform: skewX(-12.5deg) skewY(-12.5deg);
  }

  33.3% {
    transform: skewX(6.25deg) skewY(6.25deg);
  }

  44.4% {
    transform: skewX(-3.125deg) skewY(-3.125deg);
  }

  55.5% {
    transform: skewX(1.5625deg) skewY(1.5625deg);
  }

  66.6% {
    transform: skewX(-0.78125deg) skewY(-0.78125deg);
  }

  77.7% {
    transform: skewX(0.390625deg) skewY(0.390625deg);
  }

  88.8% {
    transform: skewX(-0.1953125deg) skewY(-0.1953125deg);
  }
`,i.F4`
  from {
    transform: scale3d(1, 1, 1);
  }

  50% {
    transform: scale3d(1.05, 1.05, 1.05);
  }

  to {
    transform: scale3d(1, 1, 1);
  }
`,i.F4`
  from {
    transform: scale3d(1, 1, 1);
  }

  30% {
    transform: scale3d(1.25, 0.75, 1);
  }

  40% {
    transform: scale3d(0.75, 1.25, 1);
  }

  50% {
    transform: scale3d(1.15, 0.85, 1);
  }

  65% {
    transform: scale3d(0.95, 1.05, 1);
  }

  75% {
    transform: scale3d(1.05, 0.95, 1);
  }

  to {
    transform: scale3d(1, 1, 1);
  }
`,i.F4`
  from,
  to {
    transform: translate3d(0, 0, 0);
  }

  10%,
  30%,
  50%,
  70%,
  90% {
    transform: translate3d(-10px, 0, 0);
  }

  20%,
  40%,
  60%,
  80% {
    transform: translate3d(10px, 0, 0);
  }
`,i.F4`
  from,
  to {
    transform: translate3d(0, 0, 0);
  }

  10%,
  30%,
  50%,
  70%,
  90% {
    transform: translate3d(-10px, 0, 0);
  }

  20%,
  40%,
  60%,
  80% {
    transform: translate3d(10px, 0, 0);
  }
`,i.F4`
  from,
  to {
    transform: translate3d(0, 0, 0);
  }

  10%,
  30%,
  50%,
  70%,
  90% {
    transform: translate3d(0, -10px, 0);
  }

  20%,
  40%,
  60%,
  80% {
    transform: translate3d(0, 10px, 0);
  }
`,i.F4`
  20% {
    transform: rotate3d(0, 0, 1, 15deg);
  }

  40% {
    transform: rotate3d(0, 0, 1, -10deg);
  }

  60% {
    transform: rotate3d(0, 0, 1, 5deg);
  }

  80% {
    transform: rotate3d(0, 0, 1, -5deg);
  }

  to {
    transform: rotate3d(0, 0, 1, 0deg);
  }
`,i.F4`
  from {
    transform: scale3d(1, 1, 1);
  }

  10%,
  20% {
    transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
  }

  30%,
  50%,
  70%,
  90% {
    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
  }

  40%,
  60%,
  80% {
    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
  }

  to {
    transform: scale3d(1, 1, 1);
  }
`,i.F4`
  from {
    transform: translate3d(0, 0, 0);
  }

  15% {
    transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
  }

  30% {
    transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
  }

  45% {
    transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
  }

  60% {
    transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
  }

  75% {
    transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`;var w=i.F4`
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
`,k=i.F4`
  from {
    opacity: 0;
    transform: translate3d(-100%, 100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,_=i.F4`
  from {
    opacity: 0;
    transform: translate3d(100%, 100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,E=i.F4`
  from {
    opacity: 0;
    transform: translate3d(0, -100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,O=i.F4`
  from {
    opacity: 0;
    transform: translate3d(0, -2000px, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,S=i.F4`
  from {
    opacity: 0;
    transform: translate3d(-100%, 0, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,C=i.F4`
  from {
    opacity: 0;
    transform: translate3d(-2000px, 0, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,R=i.F4`
  from {
    opacity: 0;
    transform: translate3d(100%, 0, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,T=i.F4`
  from {
    opacity: 0;
    transform: translate3d(2000px, 0, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,M=i.F4`
  from {
    opacity: 0;
    transform: translate3d(-100%, -100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,F=i.F4`
  from {
    opacity: 0;
    transform: translate3d(100%, -100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,N=i.F4`
  from {
    opacity: 0;
    transform: translate3d(0, 100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,I=i.F4`
  from {
    opacity: 0;
    transform: translate3d(0, 2000px, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`;var P=i.iv`
  opacity: 0;
`,j=i.iv`
  display: inline-block;
  white-space: pre;
`,D=t=>{const{cascade:e=!1,damping:n=.5,delay:o=0,duration:a=1e3,fraction:s=0,keyframes:c=S,triggerOnce:l=!1,css:u,className:f,style:d,childClassName:p,childStyle:m,children:g,onVisibilityChange:b}=t,w=(0,r.useMemo)((()=>function({duration:t=1e3,delay:e=0,timingFunction:n="ease",keyframes:r=S,iterationCount:o=1}){return i.iv`
    animation-duration: ${t}ms;
    animation-timing-function: ${n};
    animation-delay: ${e}ms;
    animation-name: ${r};
    animation-direction: normal;
    animation-fill-mode: both;
    animation-iteration-count: ${o};
  `}({keyframes:c,duration:a})),[a,c]);return void 0==g?null:"string"===typeof(k=g)||"number"===typeof k||"boolean"===typeof k?v(A,{...t,animationStyles:w,children:String(g)}):(0,y.isFragment)(g)?v(B,{...t,animationStyles:w}):v(x,{children:r.Children.map(g,((c,y)=>{if(!(0,r.isValidElement)(c))return null;const g=[u,w],x=o+(e?y*a*n:0);switch(c.type){case"ol":case"ul":return v(i.ms,{children:({cx:e})=>v(c.type,{...c.props,className:e(f,c.props.className),style:{...d,...c.props.style},children:v(D,{...t,children:c.props.children})})});case"li":return v(h,{threshold:s,triggerOnce:l,onChange:b,children:({inView:t,ref:e})=>v(i.ms,{children:({cx:n})=>v(c.type,{...c.props,ref:e,className:n(p,c.props.className),css:t?g:P,style:{...m,...c.props.style,animationDelay:x+"ms"}})})});default:return v(h,{threshold:s,triggerOnce:l,onChange:b,children:({inView:t,ref:e})=>v("div",{ref:e,className:f,css:t?g:P,style:{...d,animationDelay:x+"ms"},children:v(i.ms,{children:({cx:t})=>v(c.type,{...c.props,className:t(p,c.props.className),style:{...m,...c.props.style}})})})})}}))});var k},A=t=>{const{animationStyles:e,cascade:n=!1,damping:r=.5,delay:i=0,duration:o=1e3,fraction:a=0,triggerOnce:s=!1,css:c,className:l,style:u,children:f,onVisibilityChange:d}=t,{ref:p,inView:h}=m({triggerOnce:s,threshold:a,onChange:d});return n?v("div",{ref:p,className:l,css:[c,j],style:u,children:f.split("").map(((t,n)=>v("span",{css:h?e:P,style:{animationDelay:i+n*o*r+"ms"},children:t},n)))}):v(B,{...t,children:f})},B=t=>{const{animationStyles:e,fraction:n=0,triggerOnce:r=!1,css:i,className:o,style:a,children:s,onVisibilityChange:c}=t,{ref:l,inView:u}=m({triggerOnce:r,threshold:n,onChange:c});return v("div",{ref:l,className:o,css:u?[i,e]:P,style:a,children:s})};var L=i.F4`
  from,
  20%,
  40%,
  60%,
  80%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  0% {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }

  20% {
    transform: scale3d(1.1, 1.1, 1.1);
  }

  40% {
    transform: scale3d(0.9, 0.9, 0.9);
  }

  60% {
    opacity: 1;
    transform: scale3d(1.03, 1.03, 1.03);
  }

  80% {
    transform: scale3d(0.97, 0.97, 0.97);
  }

  to {
    opacity: 1;
    transform: scale3d(1, 1, 1);
  }
`,$=i.F4`
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  0% {
    opacity: 0;
    transform: translate3d(0, -3000px, 0) scaleY(3);
  }

  60% {
    opacity: 1;
    transform: translate3d(0, 25px, 0) scaleY(0.9);
  }

  75% {
    transform: translate3d(0, -10px, 0) scaleY(0.95);
  }

  90% {
    transform: translate3d(0, 5px, 0) scaleY(0.985);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,Y=i.F4`
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  0% {
    opacity: 0;
    transform: translate3d(-3000px, 0, 0) scaleX(3);
  }

  60% {
    opacity: 1;
    transform: translate3d(25px, 0, 0) scaleX(1);
  }

  75% {
    transform: translate3d(-10px, 0, 0) scaleX(0.98);
  }

  90% {
    transform: translate3d(5px, 0, 0) scaleX(0.995);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,W=i.F4`
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  from {
    opacity: 0;
    transform: translate3d(3000px, 0, 0) scaleX(3);
  }

  60% {
    opacity: 1;
    transform: translate3d(-25px, 0, 0) scaleX(1);
  }

  75% {
    transform: translate3d(10px, 0, 0) scaleX(0.98);
  }

  90% {
    transform: translate3d(-5px, 0, 0) scaleX(0.995);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,z=i.F4`
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  from {
    opacity: 0;
    transform: translate3d(0, 3000px, 0) scaleY(5);
  }

  60% {
    opacity: 1;
    transform: translate3d(0, -20px, 0) scaleY(0.9);
  }

  75% {
    transform: translate3d(0, 10px, 0) scaleY(0.95);
  }

  90% {
    transform: translate3d(0, -5px, 0) scaleY(0.985);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,V=i.F4`
  20% {
    transform: scale3d(0.9, 0.9, 0.9);
  }

  50%,
  55% {
    opacity: 1;
    transform: scale3d(1.1, 1.1, 1.1);
  }

  to {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }
`,X=i.F4`
  20% {
    transform: translate3d(0, 10px, 0) scaleY(0.985);
  }

  40%,
  45% {
    opacity: 1;
    transform: translate3d(0, -20px, 0) scaleY(0.9);
  }

  to {
    opacity: 0;
    transform: translate3d(0, 2000px, 0) scaleY(3);
  }
`,H=i.F4`
  20% {
    opacity: 1;
    transform: translate3d(20px, 0, 0) scaleX(0.9);
  }

  to {
    opacity: 0;
    transform: translate3d(-2000px, 0, 0) scaleX(2);
  }
`,G=i.F4`
  20% {
    opacity: 1;
    transform: translate3d(-20px, 0, 0) scaleX(0.9);
  }

  to {
    opacity: 0;
    transform: translate3d(2000px, 0, 0) scaleX(2);
  }
`,q=i.F4`
  20% {
    transform: translate3d(0, -10px, 0) scaleY(0.985);
  }

  40%,
  45% {
    opacity: 1;
    transform: translate3d(0, 20px, 0) scaleY(0.9);
  }

  to {
    opacity: 0;
    transform: translate3d(0, -2000px, 0) scaleY(3);
  }
`;var U=t=>{const{direction:e,reverse:n=!1,...i}=t,o=(0,r.useMemo)((()=>function(t,e){switch(e){case"down":return t?X:$;case"left":return t?H:Y;case"right":return t?G:W;case"up":return t?q:z;default:return t?V:L}}(n,e)),[e,n]);return v(D,{keyframes:o,...i})},J=i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
  }
`,K=i.F4`
  from {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }

  to {
    opacity: 0;
    transform: translate3d(-100%, 100%, 0);
  }
`,Z=i.F4`
  from {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }

  to {
    opacity: 0;
    transform: translate3d(100%, 100%, 0);
  }
`,Q=i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(0, 100%, 0);
  }
`,tt=i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(0, 2000px, 0);
  }
`,et=i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(-100%, 0, 0);
  }
`,nt=i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(-2000px, 0, 0);
  }
`,rt=i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(100%, 0, 0);
  }
`,it=i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(2000px, 0, 0);
  }
`,ot=i.F4`
  from {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }

  to {
    opacity: 0;
    transform: translate3d(-100%, -100%, 0);
  }
`,at=i.F4`
  from {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }

  to {
    opacity: 0;
    transform: translate3d(100%, -100%, 0);
  }
`,st=i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(0, -100%, 0);
  }
`,ct=i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(0, -2000px, 0);
  }
`;var lt=t=>{const{big:e=!1,direction:n,reverse:i=!1,...o}=t,a=(0,r.useMemo)((()=>function(t,e,n){switch(n){case"bottom-left":return e?K:k;case"bottom-right":return e?Z:_;case"down":return t?e?tt:O:e?Q:E;case"left":return t?e?nt:C:e?et:S;case"right":return t?e?it:T:e?rt:R;case"top-left":return e?ot:M;case"top-right":return e?at:F;case"up":return t?e?ct:I:e?st:N;default:return e?J:w}}(e,i,n)),[e,n,i]);return v(D,{keyframes:a,...o})};i.F4`
  from {
    transform: perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 0) rotate3d(0, 1, 0, -360deg);
    animation-timing-function: ease-out;
  }

  40% {
    transform: perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 150px)
      rotate3d(0, 1, 0, -190deg);
    animation-timing-function: ease-out;
  }

  50% {
    transform: perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 150px)
      rotate3d(0, 1, 0, -170deg);
    animation-timing-function: ease-in;
  }

  80% {
    transform: perspective(400px) scale3d(0.95, 0.95, 0.95) translate3d(0, 0, 0)
      rotate3d(0, 1, 0, 0deg);
    animation-timing-function: ease-in;
  }

  to {
    transform: perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 0) rotate3d(0, 1, 0, 0deg);
    animation-timing-function: ease-in;
  }
`,i.F4`
  from {
    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
    animation-timing-function: ease-in;
    opacity: 0;
  }

  40% {
    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
    animation-timing-function: ease-in;
  }

  60% {
    transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
    opacity: 1;
  }

  80% {
    transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
  }

  to {
    transform: perspective(400px);
  }
`,i.F4`
  from {
    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
    animation-timing-function: ease-in;
    opacity: 0;
  }

  40% {
    transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
    animation-timing-function: ease-in;
  }

  60% {
    transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
    opacity: 1;
  }

  80% {
    transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
  }

  to {
    transform: perspective(400px);
  }
`,i.F4`
  from {
    transform: perspective(400px);
  }

  30% {
    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
    opacity: 1;
  }

  to {
    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
    opacity: 0;
  }
`,i.F4`
  from {
    transform: perspective(400px);
  }

  30% {
    transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
    opacity: 1;
  }

  to {
    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
    opacity: 0;
  }
`;i.iv`
  backface-visibility: visible;
`,i.F4`
  0% {
    animation-timing-function: ease-in-out;
  }

  20%,
  60% {
    transform: rotate3d(0, 0, 1, 80deg);
    animation-timing-function: ease-in-out;
  }

  40%,
  80% {
    transform: rotate3d(0, 0, 1, 60deg);
    animation-timing-function: ease-in-out;
    opacity: 1;
  }

  to {
    transform: translate3d(0, 700px, 0);
    opacity: 0;
  }
`,i.F4`
  from {
    opacity: 0;
    transform: scale(0.1) rotate(30deg);
    transform-origin: center bottom;
  }

  50% {
    transform: rotate(-10deg);
  }

  70% {
    transform: rotate(3deg);
  }

  to {
    opacity: 1;
    transform: scale(1);
  }
`,i.F4`
  from {
    opacity: 0;
    transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,i.F4`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
  }
`,i.iv`
  transform-origin: top left;
`;i.F4`
  from {
    transform: rotate3d(0, 0, 1, -200deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,i.F4`
  from {
    transform: rotate3d(0, 0, 1, -45deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,i.F4`
  from {
    transform: rotate3d(0, 0, 1, 45deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,i.F4`
  from {
    transform: rotate3d(0, 0, 1, 45deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,i.F4`
  from {
    transform: rotate3d(0, 0, 1, -90deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,i.F4`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, 200deg);
    opacity: 0;
  }
`,i.F4`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, 45deg);
    opacity: 0;
  }
`,i.F4`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, -45deg);
    opacity: 0;
  }
`,i.F4`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, -45deg);
    opacity: 0;
  }
`,i.F4`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, 90deg);
    opacity: 0;
  }
`;i.F4`
  from {
    transform: translate3d(0, -100%, 0);
    visibility: visible;
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,i.F4`
  from {
    transform: translate3d(-100%, 0, 0);
    visibility: visible;
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,i.F4`
  from {
    transform: translate3d(100%, 0, 0);
    visibility: visible;
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,i.F4`
  from {
    transform: translate3d(0, 100%, 0);
    visibility: visible;
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,i.F4`
  from {
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    transform: translate3d(0, 100%, 0);
  }
`,i.F4`
  from {
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    transform: translate3d(-100%, 0, 0);
  }
`,i.F4`
  from {
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    transform: translate3d(100%, 0, 0);
  }
`,i.F4`
  from {
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    transform: translate3d(0, -100%, 0);
  }
`;i.F4`
  from {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }

  50% {
    opacity: 1;
  }
`,i.F4`
  from {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  60% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,i.F4`
  from {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  60% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,i.F4`
  from {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  60% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,i.F4`
  from {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  60% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,i.F4`
  from {
    opacity: 1;
  }

  50% {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }

  to {
    opacity: 0;
  }
`,i.F4`
  40% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  to {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,i.F4`
  40% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
  }

  to {
    opacity: 0;
    transform: scale(0.1) translate3d(-2000px, 0, 0);
  }
`,i.F4`
  40% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
  }

  to {
    opacity: 0;
    transform: scale(0.1) translate3d(2000px, 0, 0);
  }
`,i.F4`
  40% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  to {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`}}]);